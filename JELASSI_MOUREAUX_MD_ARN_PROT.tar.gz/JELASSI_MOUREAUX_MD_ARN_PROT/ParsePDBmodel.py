#!/usr/bin/env python3.4
#-*- coding: utf-8 -*-

import sys
import math,string

def parsePDBmodel(infile) :  ########### Rajouter un argument pour que l'utilisateur precise les domaines qu'il veut analyser ? ##############
    """ But : Cette fonction permet de parser les differentes conformations
        input: fichier PDB
        output: un dictionnaire dPDB 
    """

    # Vérification de la bonne ouverture du fichier
    try:
        f = open(infile, "r")
        lines = f.readlines()
        f.close()
    except:
        print("Le fichier n'a pas pu être ouvert. Vérifiez que celui-ci existe.")
        sys.exit(0) # Stop le programme



    # Initialisation des variables
    dPDB = {}
    dPDB["models"] = []
    model = 0 

    # parcoure le PDB   
    for line in lines : 
        if line[0:5] == "MODEL" : 							  # andmodel<=50Si la ligne commence par MODEL
            model = int(line[10:14])
			#~ print (model)
            if not model in dPDB["models"]:								      # Si le modele n'est pas deja dedans 
                dPDB[model] = {}
                dPDB["models"].append(model)
                dPDB[model]["domaine"] = []

            else :
                print ("Attention, deux modèles porte le même numero dans le pdb")
                sys.exit(0)
        elif line[0:4] == "ATOM" and line[72:76] != "BWAT" and line[72:74] != "CL" and line[72:73] != "C" and line[72:75] != "POT":  # and model<=50Si la ligne commence par ATOM et qu'il s'agit bien de nos domaines
            domain = line[72:76].strip()
            if not domain in dPDB[model]["domaine"] :                            # Si le domaine n'est pas encore dans le dictionnaire, on l'ajoute
				#~ print (domain)
                dPDB[model][domain] = {}                                        # On crée un dictionnaire "domain"
                dPDB[model]["domaine"].append(domain)
                dPDB[model][domain]["reslist"] = []                             # Dans "domain", on ajoute une nouvelle clé "reslist" de type tableau
            curres = int(line[22:26])                               # On regarde le résidu actuel et on retire les espaces
            if not curres in dPDB[model][domain]["reslist"] :                  		   # Si le residu n'est pas encore enregistré, on l'ajoute
                dPDB[model][domain]["reslist"].append(curres)
                dPDB[model][domain][curres] = {}                                # On crée un dictionnaire "curres" dans le dictionnaire "domain"
                dPDB[model][domain][curres]["resname"]=line[17:20].strip()      # Dans "curres", on ajoute une nouvelle clé "resname" de type tableau
                dPDB[model][domain][curres]["atomlist"] = []                    # Dans "resname", on ajoute une nouvelle clé "atomlist" de type tableau
           

            atomtype = line[12:16].strip(' ')
			#~ print (atomtype)
            dPDB[model][domain][curres]["atomlist"].append(atomtype) 
            dPDB[model][domain][curres][atomtype] = {}
            

            dPDB[model][domain][curres][atomtype]["x"] = float(line[30:38])
			#~ print (dPDB[model][domain][curres][atomtype]["x"])
            dPDB[model][domain][curres][atomtype]["y"] = float(line[38:46])
			#~ print (dPDB[model][domain][curres][atomtype]["y"])
            dPDB[model][domain][curres][atomtype]["z"] = float(line[46:54])
			#~ print (dPDB[model][domain][curres][atomtype]["z"])
            dPDB[model][domain][curres][atomtype]["id"] = line[6:11].strip()
			#~ print (dPDB[model][domain][curres][atomtype]["id"])
    return dPDB


#~ dPDB = parsePDBmodel("./pab21_prod_solute_500frames.pdb")
#~ model = dPDB["models"]
#~ print ("Liste des modeles %s\n" % model)
#~ domaine = dPDB[10]["domaine"] # Recupere la liste des domaines
#~ print ("Liste des domaines %s\n" % domaine)
#~ domaine = dPDB[10]["A1"]		# Accede au domaine A1
#~ print ("domaine A1 %s\n" % domaine)
#~ domaine = dPDB[10]["A1"]["reslist"] # Récupère la listes des numéros de résidus
#~ print ("Liste des résidus %s\n" % domaine)
#~ domaine = dPDB[10]["A1"][24] # Récupère le residu 24
#~ print ("Accès au résidus X %s\n" % domaine)
#~ domaine = dPDB[10]["A1"][24]["atomlist"] # Récupère la liste des atomes
#~ print ("Liste des atomes pour un résidus %s\n" % domaine)
#~ domaine = dPDB[10]["A1"][24]["resname"]	# Récupère le nom du résidus
#~ print ("Nom du résidus %s\n" % domaine)
#~ for i in dPDB[10]["A1"][24]["atomlist"]:
	#~ domaine = dPDB[10]["A1"][24][i]["x"] # Récupère la coordonné x des atomes du résidu
	#~ print ("Coordonnées d'un atome %s\n" % domaine)
