#!/usr/bin/env python
# -*- coding: utf-8 -*-

#!/usr/bin/env python
# -*- coding : utf8 -*-

"""
Auteurs : MOUREAUX Cecile & JELASSI Sarah
Date: 21/05/2018
Objectif : Etude du complexe sRNP H/ACA
"""

from RMSD import * 
from Interface import * 
from Outils import * 
from math import sqrt

def usage():
    print ("""
   
    Entree:  - fichier PDB : structure de référence .
             - fichier PDB : les conformations des domaines lors de la dynamique. 
             
    Sortie: - "Calcul du RMSD" : fichier contenant le RMSD global pour chaque modele et le local pour chaque domaine.
            - "Residus Interface Protéine_ARN" : fichier contenant les résidus à l'interface de la protéine et de l'ARN
            - "Temps de contact" : temps de contact entre une liste de résidus entrée manuellement.

    Arguments obligatoires: -ref : le fichier PDB avec les structures de références.
							-conf : le fichier PDB avec les conformations des domaines.
    
    Argument optionnels: - mode_RMSD : mode de calcul pour le calcul du RMSD.
						 - seuil : seuil à partir duquel les résidus sont en contact.
						 - mode_Interface : mode de calcul pour la détermination de l'interface.
						 - duree_dyn : durée de la dynamique
    """)


# Pour compiler : python3 main.py -ref "pab21_structure_de_ref.pdb" -conf "pab21_prod_solute_500frames.pdb"

############ Recuperation des arguments ############

try:
    pdb_ref = sys.argv[sys.argv.index("-ref")+1]
except:
    usage()
    print("Veuillez entrer un fichier de reference")
    sys.exit()

try:
    pdb_conf = sys.argv[sys.argv.index("-conf")+1]
except:
    usage()
    print("Veuillez entrer un fichier de conf")
    sys.exit()
    
try:
    seuil_contact = float(sys.argv[sys.argv.index("-seuil")+1])
except:
    seuil_contact = 8.0

try:
    mode_RMSD = sys.argv[sys.argv.index("-mode_RMSD")+1]
except:
    mode_RMSD = "CM"

try:
    duree_dyn = sys.argv[sys.argv.index("-dyn")+1]
except:
    duree_dyn = 10
    
############ Debut execution ############

	### Creation des dictionnaires ###
	
print ("Les dictionnaires de vos fichiers PDB sont en cours de création") 
dPDB_ref = ParsePDBref.parsePDBref("./pab21_structure_de_ref.pdb")
print ("Le dictionnaire de réference est pret")
dPDB_conf = ParsePDBmodel.parsePDBmodel("./pab21_prod_solute_500frames.pdb")
print ("Le dictionnaire de conformation est pret")
print ("Vos dictionnaires ont été crées")

	### Autres parametres ###
	
liste_domaine = dPDB_ref["domaine"] 
print ("Les domaines présents sont : ")
print (liste_domaine)

liste_domaine = input("Quels sont les domaines protéique à étudier ? \nPar exemple: A1,A2,A3,A4\n").split(sep=",")
ARN_domaine = input("Quels est le domaine representant l'ARN ? \nPar exemple: B\n")

	### RMSD local et global ###

print ("Calcul du RMSD")
output = "RMSD"
RMSDisplay(dPDB_ref,dPDB_conf,liste_domaine,mode_RMSD,output)

	### Residu à l'interface ###
print ("Recherche des résidus à l'interface Protéine/ARN, les distances seront calculée avec le mode: CM")
output2 = "Residus_Interface_Proteine_ARN_seuil_8"
mode_Interface = "CM" 
#On crée une variable mode_Interface qu'on intialise à "CM" pour le calcul de distance avec l'ARN
interface(dPDB_conf, liste_domaine, ARN_domaine, seuil_contact, mode_Interface, output2)

	### Temps de contact ###
	
print ("Calcul des temps de contact entre paires de résidus choisi en fonction de l'article")	
output3="Temps_de_contact_seuil_8"
dico_paires_res= {34: {'dom1':'A3', 'res2':33, 'dom2':'B'},
46: {'dom1':'A4', 'res2':25, 'dom2':'B'},38: {'dom1':'A4', 'res2':26, 'dom2':'B'},50: {'dom1':'A4', 'res2':23, 'dom2':'B'},
50: {'dom1':'A4', 'res2':24, 'dom2':'B'}, 43: {'dom1':'A4', 'res2':26, 'dom2':'B'},
98: {'dom1':'A4', 'res2':30, 'dom2':'B'}}
temps_contact(dico_paires_res, dPDB_conf, seuil_contact, duree_dyn, mode_Interface, output3)

	### Heatmap domain vs ARN ###

print ("Création de HeatMap de distance entre domaine et ARN, la distance sera calculée avec le mode :  CM" )
for dom in liste_domaine:
    HeatMap_dist (dPDB_ref,dom,ARN_domaine)


	### RMSD croisee ###

print ("Création de HeatMap de distance croisé au sein d'un domaine" )
mode_RMSD_croise = input("Quel mode voulez vous utiliser pour caculer le RMSD croisé:\nCA (sur les carbones alpha) ou CM (sur les centres de masse)?\n")
for dom in liste_domaine:
    print(dom)
    liste = RMSDcroisee(dPDB_conf,dom,mode_RMSD_croise)

print ("Fin du programme")




