#!/usr/bin/env python3.4
# -*- coding : utf8 -*-

import sys
import math,string
from RMSD import *
from Outils import *
from math import sqrt

def interface(dPDB_conf, liste_domaine, ARN_domaine, seuil_contact, mode, output):
	"""
	Détermination des résidus à l'interface de la protéine et de l'ARN et leur fréquence d'appartenance à l'interface.
	input: dPDB_conf: dictionnaire des conformations des domaines lors de la dynamique.
		   liste_domaine : liste des domaines à étudier, entré par l'utilisateur.
		   ARN_domaine : le domaine représentant l'ARN
		   seuil_contact : seuil à partir duquel les résidus sont en contact.
		   mode: deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
										  CM, calcul du RMSD par rapport au centre de masse du residu
	output: fichier contenant la fréquence d'appartenance à l'interface de la protéine et de l'ARN
    """
    
	Dico_interface = dict() # Dictionnaire contenant les résidus à l'interface et le nombre de fois où ils y apparaissent.
	 
	for dom in liste_domaine : # Pour chaque domaine de la liste entrée en paramètre.
		    
		Dico_interface[dom] = dict() #Création des clés du dictionnaire
		Dico_interface[dom]["reslist"] = []
		
		for mod in dPDB_conf["models"]: #Pour chaque modèle
			for res1 in dPDB_conf[mod][dom]["reslist"]: #Pour chaque résidus du domaine 
				if res1 not in Dico_interface[dom]["reslist"]: #Si le résidus n'a pas encore été étudié on créer une clé.
					Dico_interface[dom][res1] = 0              
					Dico_interface[dom]["reslist"].append(res1)
					
				liste_distance = list () # liste contenant toutes les distances calculées entre le résidu "res1" et les résidus de l'ARN
				dist_min = 1000 # valeur minimum choisie abitrairement
				
				for res2 in dPDB_conf[mod][ARN_domaine]["reslist"]:
					dist = sqrt (Distance (dPDB_conf[mod][dom][res1],dPDB_conf[mod][ARN_domaine][res2],mode)) #Calcul de la distance. 
					liste_distance.append(dist) # On stocke les distances dans la liste
					
				dist_min = min_liste(liste_distance) # On cherche la distance minimale 
				if dist_min <= seuil_contact: # si la distance minimale est inférieure ou égale à la distance seuil on incrémente le nombre d'apparition du res1 dans l'interface
					Dico_interface[dom][res1] = Dico_interface[dom][res1] + 1
					
	f = open(output, "w")
	for dom in Dico_interface.keys(): #Pour chaque domaine
		f.write("Domaine\t" + dom + "\tResidue\tFrequence \n")
		for res in Dico_interface[dom]['reslist']:
			freq = Dico_interface[dom][res] / len (dPDB_conf["models"]) #calcul de la fréquence d'appartenance à l'interface 
			if freq != 0:
				f.write("\t\t\t" + str(res) + "\t\t" + str(freq) + "\n")
				f.write("\n")
	
	f.close()


			
def temps_contact(dico_paires_res, dPDB_conf, seuil_contact, duree_dyn, mode, output):
	"""
	Détermination des résidus à l'interface de la protéine et de l'ARN et leur fréquence d'appartenance à l'interface.
	input: dico_paires_res: dictionnaire contenant les paires de résidus choisie.
		   dPDB_conf: dictionnaire des conformations des domaines lors de la dynamique.
		   ARN_domaine : le domaine représentant l'ARN.
		   seuil_contact : seuil à partir duquel les résidus sont en contact.
		   duree_dyn : durée de la dynamique.
		   mode: deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
										  CM, calcul du RMSD par rapport au centre de masse du residu
	output: fichier contenant les temps de contact.
    """
	f=open(output, "w")
	f.write("Temps de contact entre les résidues entrée de manière manuelle avec le mode :" +str(mode)+"\n") 
	for res1 in dico_paires_res.keys(): #Pour chaque residu du dictionnaire
		dico_paires_res[res1]['temps de contact'] = 0
		for mod in dPDB_conf["models"]: #Pour chaque modèle
			dom1 = dico_paires_res[res1]['dom1']
			dom2 = dico_paires_res[res1]['dom2'] 
			res2 = dico_paires_res[res1]['res2']
			d = sqrt (Distance (dPDB_conf[mod][dom1][res1],dPDB_conf[mod][dom2][res2],mode))
			if d <= seuil_contact:
				dico_paires_res[res1]['temps de contact'] += 1

		dico_paires_res[res1]['temps de contact'] = dico_paires_res[res1]['temps de contact']*duree_dyn/len(dPDB_conf["models"])
		
		
		f.write ("\nRésidu 1 \t\tRésidu ARN \t\t Temps de contact \n")
		f.write(str(res1) +" "+ str(dico_paires_res[res1]['dom1'])+ " \t\t\t " + str(dico_paires_res[res1]['res2'])  + "\t\t\t\t" +
        str(dico_paires_res[res1]['temps de contact']) + " ns\n")

	f.close()
