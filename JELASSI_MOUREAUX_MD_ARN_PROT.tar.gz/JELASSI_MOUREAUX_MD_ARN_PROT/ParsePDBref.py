#!/usr/bin/env python3.4
#-*- coding: utf-8 -*-

import sys
import math,string

def parsePDBref(infile) :
    """ But : Cette fonction permet de parser un fichier PDB au format ATOM
        input: fichier PDB
        output: un dictionnaire dPDB 
    """

    # Vérification de la bonne ouverture du fichier
    try:
        f = open(infile, "r")
        lines = f.readlines()
        f.close()
    except:
        print("Le fichier n'a pas pu être ouvert. Vérifiez que celui-ci existe.")
        sys.exit(0) # Stop le programme



    # Initialisation des variables
    dPDB = {}
    dPDB["domaine"] = []
    
    
    # parcoure le PDB   
    for line in lines : 
       if line[0:4] == "ATOM" and line[72:76] != "BWAT" and line[72:74] != "CL" and line[72:73] != "C" and line[72:75] != "POT": # Si la ligne commence par ATOM et qu'il s'agit bien de nos domaines
            domain = line[72:76].strip()  
			#~ print (domain)
            if not domain in dPDB["domaine"] :                            # Si la domaine n'est pas encore dans le dictionnaire, on l'ajoute
                dPDB[domain] = {}                                        # On crée un dictionnaire "domain"
                dPDB["domaine"].append(domain)
                dPDB[domain]["reslist"] = []                             # Dans "domain", on ajoute une nouvelle clé "reslist" de type tableau
            curres = int(line[22:26])                                    # On regarde le résidu actuel et on retire les espaces
			#~ print (curres)
            if not curres in dPDB[domain].keys() :                   # Si le residu n'est pas encore enregistré, on l'ajoute
                dPDB[domain]["reslist"].append(curres)
                dPDB[domain][curres] = {}                                # On crée un dictionnaire "curres" dans le dictionnaire "domain"
                dPDB[domain][curres]["resname"]=line[17:20].strip()      # Dans "curres", on ajoute une nouvelle clé "resname" de type tableau
                dPDB[domain][curres]["atomlist"] = []                    # Dans "resname", on ajoute une nouvelle clé "atomlist" de type tableau
           

            atomtype = line[12:16].strip(' ')
			#~ print (atomtype)
            dPDB[domain][curres]["atomlist"].append(atomtype) 
            dPDB[domain][curres][atomtype] = {}

            dPDB[domain][curres][atomtype]["x"] = float(line[30:38])
			#~ print (dPDB[domain][curres][atomtype]["x"])
            dPDB[domain][curres][atomtype]["y"] = float(line[38:46])
			#~ print (dPDB[domain][curres][atomtype]["y"])
            dPDB[domain][curres][atomtype]["z"] = float(line[46:54])
			#~ print (dPDB[domain][curres][atomtype]["z"])
            dPDB[domain][curres][atomtype]["id"] = line[6:11].strip()
			#~ print (dPDB[domain][curres][atomtype]["id"])

    return dPDB

#~ dPDB = parsePDBref("./pab21_structure_de_ref.pdb")
#~ domaine = dPDB["domaine"] # Recupere la liste des domaines
#~ print ("Liste des domaines %s\n" % domaine)
#~ domaine = dPDB["A1"]		# Accede au domaine A1
#~ print ("Domaine A1 %s\n" % domaine)
#~ domaine = dPDB["A1"]["reslist"] # Récupère la listes des numéros de résidus
#~ print ("Liste des résidus %s\n" % domaine)
#~ domaine = dPDB["A1"][12] # Récupère le residu 24
#~ print ("Accès au résidus X %s\n" % domaine)
#~ domaine = dPDB["A1"][12]["atomlist"] # Récupère la liste des atomes
#~ print ("Liste des atomes pour un résidus %s\n" % domaine)
#~ domaine = dPDB["A1"][12]["resname"]	# Récupère le nom du résidus
#~ print ("Nom du résidus %s\n" % domaine)
#~ for i in dPDB["A1"][12]["atomlist"]:
	#~ domaine = dPDB["A1"][12][i]["x"] # Récupère la coordonné x des atomes du résidu
	#~ print ("Coordonnées d'un atome %s\n" % domaine)
