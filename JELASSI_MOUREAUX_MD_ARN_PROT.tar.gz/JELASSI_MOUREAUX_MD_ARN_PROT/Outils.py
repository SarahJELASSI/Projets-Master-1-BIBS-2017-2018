from math import sqrt
import matplotlib.pyplot as plt
import numpy
import pylab

def distanceCarree(dico1,dico2):
    """
    Calcul la distance au carrre entre 2 points.
    input : dico1: dictionnaire contenant le premier residu.
            dico2: dictionnaire contenant le deuxième residu..
    output: la distance au carre entre les deux residus.
    """
    
    return ((dico1['x']-dico2['x'])**2 + (dico1['y']-dico2['y'])**2 + (dico1['z']-dico2['z'])**2)

def centreDeMasse(dico):
	"""
	Calcul le centre de masse des residus contenus dans le PDB.
	input:  dico: dictionnaire de la proteine.
	ouput: dictionnaire compose des coordonnees du centre de masse de la molecule.
	"""
	
	nbatom = len(dico["atomlist"])
	x = float(0)
	y = float(0)
	z = float(0)
	coord_CM={}
	for atom in dico["atomlist"]:
		x = x + dico[atom]["x"]
		y = y + dico[atom]["y"]
		z = z + dico[atom]["z"]
	
	coord_CM["x"] = round(x/nbatom,4)
	coord_CM["y"] = round(y/nbatom,4)
	coord_CM["z"] = round(z/nbatom,4)

	return coord_CM

def Distance (dico1, dico2, mode) : 
	"""
	Calcul la distance entre deux résidus
	input:  dico1: dictionnaire de la proteine contenant le premier résidu
			dico2: dictionnaire de la proteine contenant le deuxième résidu
			mode : mode de calcul des distances :  CA ou CM
	ouput: la distance entre les deux résidus.
	"""
	dico_res1 = dict () 
	dico_res2 = dict ()
	
	if mode == "CA" : 
		for atom1 in dico1["atomlist"]:
			if atom1 == 'CA':
				dico_res1["x"] = dico1[atom1]["x"]
				dico_res1["y"]  = dico1[atom1]["y"]
				dico_res1["z"] = dico1[atom1]["z"]
				
		for atom2 in dico2["atomlist"]:
			if atom2 == 'CA':
				dico_res2["x"]  = dico2[atom2]["x"]
				dico_res2["y"] = dico2[atom2]["y"]
				dico_res2["z"] = dico2[atom2]["z"]
		dist = distanceCarree(dico_res1,dico_res2)		
		
	elif mode == "CM": 
		CM_res1 = centreDeMasse(dico1)
		CM_res2 = centreDeMasse(dico2) 
		dist = distanceCarree(CM_res1,CM_res2)
	
	return (dist)
	
	
def min_liste(L):
	"""
	Cherche la valeur minimale d'une liste
	input: L: une liste.
	ouput: la valeur minimale de la liste.
	"""
	
	min=L[0] # on considére que le premier élément de la liste est le plus petit

	for i in L: 
		if min > i : # Si on trouve un élément i de la liste plus petit que min on met dans min l'élément i
			min=i

	return min

def Graphe (x_mod,y_global,y_local,liste_domaine,mode):
	"""
	Trace des graphiques.
	input:  x_mod: liste contenant les valeurs des modèles.
			y_global : liste contenant les valeurs des RMSD globaux.
			y_local :dictionnaire contenant la valeur du RMSD de chaque domaine.
			liste_domaine: liste des domaines protéique a etudier
	ouput: 5 graphiques, un pour le RMSD global et 4 autres pours les RMSD locaux des domaines protéique.
	"""
	
	#Construction du graphique pour le RMSD global 
	plt.plot(x_mod, y_global)
	plt.xlabel('Modèles ')
	plt.ylabel('RMSD en Angstrom')
	plt.title('RMSD global (réalisé avec le mode de calcul : %s)'%(mode))
	plt.show()
	
	
	#Construction des graphiques pour les RMSD locaux.
	for i in range(len(liste_domaine)):
		plt.plot(x_mod, y_local[liste_domaine[i]], label=liste_domaine[i])
		plt.xlim(0, 5000)
		plt.ylim (0.5,4)
		plt.xlabel('Modèles')
		plt.ylabel('RMSD en Angstrom')
		plt.title('RMSD local du domaine '+liste_domaine[i] +' (réalisé avec le mode de calcul ' +mode+')')
		plt.legend(loc=4)
		plt.show()
        

def HeatMap_dist (dico,dom1,dom2) :
	"""
	Trace une matrice de distance sous la forme d'une heatmap
	input:  dico: dictionnaire les 2 domaines nécessaire pour le calcul de distance.
			dom1 : le premier domaine 
			dom2 : le deuxième domaine
	ouput: 5 graphiques, un pour le RMSD global et 4 autres pours les RMSD locaux des domaines protéique.
	"""
    
	plt.clf() ## Reinitialise le plot

	list_res1=dico[dom1]["reslist"]
	list_res2=dico[dom2]["reslist"]
	n=len(dico[dom1]["reslist"])
	m=len(dico[dom2]["reslist"])
	list_dist=[]
    
	for res1 in dico[dom1]["reslist"]:
		liste=[]
		for res2 in dico[dom2]["reslist"]:
			dist = sqrt(Distance (dico[dom1][res1],dico[dom2][res2],"CM"))
			liste.append(dist)
		list_dist.append(liste)
    

	matrice_dist = numpy.array(list_dist).reshape(n,m)
	pylab.pcolor(matrice_dist)
	pylab.colorbar()
	title_name = "Matrice de distance entre " + dom1 + " et " + dom2
	pylab.title(''.join(title_name))
	plt.xlabel(dom2)
	plt.ylabel(dom1)
    
    ### Détermination numero residu : pour taille du plot
	x1 = list_res2[0]
	x2 = list_res2[-1]
	y1 = list_res1[0]
	y2 = list_res1[-1]
	axe = [0,x2-x1,0,y2-y1]
	plt.axis(axe)
	pylab.xticks(pylab.arange(x1,x2,10),range(x1,x2,10),fontsize=10)
	pylab.yticks(pylab.arange(0,y2-y1,10),range(y1,y2,10),fontsize=8)
	pylab.savefig("./" + dom1 + "_vs_" + dom2 + ".png",figsize=(n,m),dpi=100)
	plt.show ()
	
	

