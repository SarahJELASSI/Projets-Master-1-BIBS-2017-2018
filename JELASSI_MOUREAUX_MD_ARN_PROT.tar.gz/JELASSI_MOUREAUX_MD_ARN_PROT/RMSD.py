#!/usr/bin/env python3.4
# -*- coding : utf8 -*-

import ParsePDBref
import ParsePDBmodel
import Interface 
from Interface import *
from Outils import * 

def RMSDglobal(dref,dconf,liste_domaine,mod,mode):
	"""
	Calcul du RMSD global de la structure d'origine au long de la dynamique.
	input : dref : dictionnaire de la structure de référence de la proteine
			dconf : dictionnaire des conformations des domaines lors de la dynamique.
			liste_domaine: liste des domaines a étudier.
			mode : deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
											CM, calcul du RMSD par rapport au centre de masse du residu
	output: RMSD gobal
	"""
    
	N = 0 # N correspond au nombre total de paires d'atome.
	somme = float(0)
	dist = float(0)
	
	for dom in liste_domaine: # Pour chaque domaine
		for res in dref[dom]["reslist"]:				                # Pour chaque residu du domaine
			dist = Distance(dref[dom][res], dconf[dom][res],mode)
			somme += dist 
			N += 1  
	RMSDglob = sqrt(somme /N) 
	
	return (round(RMSDglob,4))


def RMSDlocal(dref,dconf,dom,modele,mode): 
	"""
	Calcul le RMSD local pour chacun des domaines.
	input: dref : dictionnaire de la structure de référence de la proteine
		   dconf : dictionnaire des conformations des domaines lors de la dynamique.
		   dom : domaine a étudier 
		   modele: modele a étudier
		   mode: deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
										  CM, calcul du RMSD par rapport au centre de masse du residu
	output: RMSD local
	"""

	N = 0 # N correspond au nombre total de paires d'atome.
	somme = float(0)
	dist = float(0)
	liste_aa=(dref[dom]["reslist"])
	
	for res in liste_aa: # Pour chaque résidu du domaine entré en paramètre
		dist = Distance(dref[dom][res], dconf[dom][res],mode)
		somme += dist
		N += 1
	RMSDlocal = sqrt(somme/N)
	
	return (round(RMSDlocal,4))
	

def RMSDcroisee(dconf,dom,mode):
    """
	Calcul les RMSD croisés pour chacun des domaines.
	input: dconf : dictionnaire des conformations des domaines lors de la dynamique.
		   mod: modele a etudier
		   mode: deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
										  CM, calcul du RMSD par rapport au centre de masse du residu
	output: RMSD local
	"""

    
    plt.clf() ## Reinitialise le plot

    i=0
    j=0
	
    n = len(dconf["models"])
    matrice_RMSD = numpy.zeros((n,n))
	                  
   
    for i in range (n): #Pour chacun des domaines
        mod1 = dconf["models"][i]
        for j in range (i,n):
            mod2 = dconf["models"][j]
            somme = float(0)
            N = 0
            for res in dconf[mod1][dom]["reslist"]:
                dist = Distance(dconf[mod1][dom][res], dconf[mod2][dom][res],mode)
                somme += dist
                N += 1
    
            RMSDcroisee = sqrt(somme/N)
            matrice_RMSD[i,j]=RMSDcroisee
            matrice_RMSD[j,i]=matrice_RMSD[i,j]
            
       
		
    pylab.pcolor(matrice_RMSD)
    pylab.colorbar()
    title_name = "Matrice de distance croisée pour " + dom + "  Mode : " + mode
    pylab.title(''.join(title_name))
    plt.xlabel("Numéro du modèle")
    plt.ylabel("Numéro du modèle")
    axe = [0,n,0,n]
    plt.axis(axe)
    pylab.savefig("./RMSD_croise_" + dom + "_mode_" + mode + ".png",figsize=(n,n),dpi=100)
    plt.show()
    
    return

	


def RMSDisplay (dref,dconf,liste_domaine,mode,output):
    """
    Rassemble les données calculé par les fonctions RMSDglobal et RMSDlocal dans un fichier.
    input:  dref : dictionnaire de la structure de référence de la proteine
            dconf : dictionnaire des conformations des domaines lors de la dynamique.
            liste_domaine : liste des domaines à traiter
            mode: deux modes disponibles : CA, calcul du RMSD par rapport au carbone alpha
                                        CM, calcul du RMSD par rapport au centre de masse du residu
                                        output : nom du fichier où sont stocké les informations
    output: fichier récapitulatif des RMSD globaux et locaux.
    """
    
    out = open(output,"w")                                     
    liste_mod = list() # Liste contenant les valeurs des modèles.
    liste_RMSDglobal = list() # Liste contenant les valeurs des RMSD globaux.
    dico_RMSDlocal = dict() #Dictionnaire contenant la valeur du RMSD de chaque domaine.
    
    out.write ("Calcul des RMSD avec le mode : " + mode+"\n")
    out.write ("Conformation\t RMSD global\t Domaine A1\t Domaine A2\t Domaine A3\t Domaine A4\t\n")
    
    for mod in dconf["models"]: #Pour chaque modèle 
        RMSDg = RMSDglobal(dref,dconf[mod],liste_domaine,mod,mode) #Calcul du RMSD global
		
        liste_mod.append(mod) # stockage du modèle dans une liste 
        liste_RMSDglobal.append(RMSDg) #stockage du RMSD global
		
        out.write("\t\t" + str(mod) + "\t\t" + str(RMSDg)+ "\t\t")
		
        for dom in liste_domaine: #Pour chaque domaine 
            RMSDl = RMSDlocal(dref,dconf[mod],dom,mod,mode) #Calcul du RMSD local
            out.write(str(RMSDl)+ "\t\t")
			
            if dom not in dico_RMSDlocal.keys(): #Pour chaque domaine 
                dico_RMSDlocal[dom] = [] # on remplit le dictionnaire en prenant pour clé les domaines.
            dico_RMSDlocal[dom].append(RMSDl)
		
        out.write("\n")
		
    Graphe (liste_mod,liste_RMSDglobal,dico_RMSDlocal,liste_domaine,mode) #Traçage des graphiques
    out.close()
    
         
