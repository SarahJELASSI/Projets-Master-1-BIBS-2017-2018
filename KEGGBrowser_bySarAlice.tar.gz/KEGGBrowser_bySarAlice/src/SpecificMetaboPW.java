import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileNotFoundException;
import javax.imageio.ImageIO;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 * Loads and displays the specific metabolic pathway map desired. 
 * Records all the needed datas about the .conf file of the map desired. 
 * 
 * @author SarAlice Laboratory�
 * @version 6.6.6
 * 
 */
public class SpecificMetaboPW extends JLabel implements Loadable {

	// Attributes

	/**
	 * The image where the .png of the specific metabolic pathway will be displayed.
	 */
	static 	BufferedImage image = null;

	/**
	 * The species ID of the metabolic pathway.
	 */
	private String species;
	
	/**
	 * The map ID of the metabolic pathway.
	 */
	private String map_id;
	
	/**
	 * The hashtable .
	 */
    private Hashtable<String, List<String>> dict;

	// Constructors
    
	/**
	 * Constructor of the specific metabolic pathway.
	 */
	public SpecificMetaboPW() {
	   
		ImageIcon defaultIcon = new ImageIcon("kegg_header1.jpg");
		setIcon(defaultIcon);
		
	}
	
	/**
	 * Constructor of the specific metabolic pathway.
	 * 
	 * @param species
	 * @param map_id
	 */

	public SpecificMetaboPW(String species, 
							String map_id) {
		
		this.species = species; 
		this.map_id = map_id;
		setParam ( species, map_id) ;
	}

	// Methods
	
	/**
	 * Set the parameters for the specific metabolic pathway and update it.	 * 
	 * @param species
	 * @param map_id
	 */
	public void setParam (String species, String map_id) {

		this.species = species; 
		this.map_id = map_id;
		loadFiles();

		String fileName = ".\\KEGG files\\Files conf\\"+species+map_id+".conf";

		try {
			this.dict=generateDict(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		setIcon(new ImageIcon(image));
	}
	
	/**
	 * Check if the wanted information are present locally 
	 * @return boolean: file is saved locally or not
	 */
	
	public boolean localLoad () {
		String voiepngname = ".\\KEGG files\\Files image\\"+species+map_id+".png";
		File voiepng = new File(voiepngname);
		
		if (!voiepng.exists()) 	return false;
		else {
			try {
				image = ImageIO.read(new File(".\\KEGG files\\Files image\\"+species+map_id+".png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
			return true;
		}
	}
	
	/**
	 * Loads the pathway map desired on the Internet
	 */
	
	public void internetLoad (){
		
		URL url;
		try {
			url = new URL("http://rest.kegg.jp/get/"+species+map_id+"/Image");
			image = ImageIO.read(url);
			ImageIO.write(image, "png", new File(".\\KEGG files\\Files image\\"+species+map_id+".png"));
		} catch (IOException e) {
			JFrame fenetre_erreur= new JFrame();
			ImageIcon Icon = new ImageIcon("try_and_catch.jpg");
			
			JOptionPane.showMessageDialog(fenetre_erreur, 
			         "The MapID does not exist or you do not have the Internet",
			         " Error ",
			         JOptionPane.WARNING_MESSAGE,
			         Icon);
			e.printStackTrace();
			}
		
		URL url2;
		try {
			// get URL content
			url2 = new URL("http://rest.kegg.jp/get/"+species+map_id+"/conf");
			URLConnection conn = url2.openConnection();

			// open the stream and put it into BufferedReader
			BufferedReader br = new BufferedReader(
							   new InputStreamReader(conn.getInputStream()));

			String inputLine;
			//save to this filename
			String fileName = ".\\KEGG files\\Files conf\\"+species+map_id+".conf";
			File file = new File(fileName);

			if (!file.exists()) {
				file.createNewFile();
			}

			//use FileWriter to write file
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			while ((inputLine = br.readLine()) != null) {
				bw.write(inputLine);
				bw.write ("\n");
			}
			bw.close();
			br.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Returns the metabolic pathway image 
	 * @return image : the image of the specific metabolic pathway
	 */
	
	public BufferedImage getImage() {
		return image;
	}
	
	/**
	 * Generates and returns the hashtable of .conf of the specific metabolic pathway.
	 * 
	 * @param filename
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	
	public Hashtable<String,List<String>> generateDict(String filename) throws FileNotFoundException, IOException  {
		
	    String line;
	    Hashtable<String,List<String>> dict=new Hashtable<String,List<String>>();
	    File file = new File(filename);
		
		FileReader fr = new FileReader(file.getAbsoluteFile());
		BufferedReader br = new BufferedReader(fr);
		
		// Reading the .conf line by line 
		while ((line = br.readLine()) != null){
			
			//Selecting the right line
			Pattern pattern = Pattern.compile("(rect(.+,.+))\t(/dbget-bin/www_bget?.+)\t(.+)");
			Matcher matcher = pattern.matcher(line);
		    
			while(matcher.find()) {

			    List<String> listGene = new ArrayList<String>();
			    
				String cle = matcher.group(2);
				cle=cle.replace("(","");
				cle=cle.replace(")","");
				cle=cle.replace("\t","");
				
				//Split the url in order to find the reaction 
				String url =matcher.group(3);
				if (url.contains(":")) {
					String[] sep_interro = url.split("\\?");
					String[] sep_plus = sep_interro[1].split("\\+");
					for (int j=0; j<sep_plus.length;j++) {
						String[] sep_2p = sep_plus[j].split("\\:");
						listGene.add(sep_2p[1]);	
					}			
				}
				
				Pattern pattern2 = Pattern.compile("(.+),(.+) (.+),(.+)");
				Matcher matcher2 = pattern2.matcher(cle);
				while(matcher2.find()) {
					   dict.put(matcher2.group(1)+" "+matcher2.group(2), listGene);
				}
		    }
		}
		br.close();
		return(dict);
	}
	
	/**
	 * Returns the hashtable of the .conf file loaded 
	 * @return dict : the hashtable generated with the .conf file
	 */

	public Hashtable <String,List<String>> getDict () {
		return(this.dict);
	}
	
	
	
}
