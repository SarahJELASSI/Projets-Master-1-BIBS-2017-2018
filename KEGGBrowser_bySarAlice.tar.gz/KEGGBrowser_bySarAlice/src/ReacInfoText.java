import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.io.IOException;
import java.net.MalformedURLException;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.net.URLConnection;
import java.io.InputStreamReader;


/**
 * Loads and displays pieces of information about the reaction clicked by the user.
 * 
 * @author SarAlice Laboratory�
 * @version 1.61
 */
public class ReacInfoText extends JTextPane implements Loadable {
	
	// Attributes
	
	
	/**
	 * The reaction ID.
	 */
	private String reaction;
	
	/**
	 * The image of the reaction.
	 */
	private BufferedImage image;
	
	// Constructor 
	/**
	 * ReacInfoText constructor
	 * @param reaction
	 */
	public ReacInfoText (String reaction) {
		
		this.reaction=reaction;
		
	}
	
	/**
	 * Updates the informations about the reaction desired
	 * @param reaction
	 */
	// Methods
	public void reload (String reaction) {
		
		System.out.println("ReacInfoText: reload Beginning ");
		this.reaction=reaction;
		loadFiles();
		this.setTxt(reaction);
		System.out.println("ReacInfoText: reload End ");
		
	}
	
	/**
	 * Checks and returns "true" if the .txt file with all the informations exists locally
	 * @return boolean 
	 */

	public boolean localLoad () {
		
		String fileName = ".\\KEGG files\\Files txt\\info_"+reaction+".txt";
		File file = new File(fileName);
		if (!file.exists()) return false;
		else return true;
		
	}
	
	/**
	 * Loads informations about the reactions on the Internet and writes it in a .txt
	 */
	
	public void internetLoad () {
		
		URL url;
		try {
			// get URL content
			url = new URL("http://rest.kegg.jp/get/rn:"+reaction);
			URLConnection conn = url.openConnection();

			// open the stream and put it into BufferedReader
			BufferedReader br = new BufferedReader(
								new InputStreamReader(conn.getInputStream()));

			String inputLine;

			//save to this filename
			String fileName = ".\\KEGG files\\Files txt\\info_"+reaction+".txt"; //A TERMES REGARDER LE CHEMIN RELATIF
			File file = new File(fileName);

			if (!file.exists()) {
				file.createNewFile();
			}

			//use FileWriter to write file
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			while ((inputLine = br.readLine()) != null) {
				bw.write(inputLine);
				bw.write ("\n");
			}

			bw.close();
			br.close();

		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			url = new URL("http://rest.kegg.jp/get/"+reaction+"/Image");
			image = ImageIO.read(url);
			ImageIO.write(image, "gif", new File(".\\KEGG files\\Files image\\"+reaction+".gif"));
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	/**
	 * Set the text from the txt files to the TextArea
	 * @param reaction
	 */
	public void setTxt(String reaction) {
		
		this.reaction=reaction;
		setText("");
		String filename = ".\\KEGG files\\Files txt\\info_"+reaction+".txt";
		File file = new File(filename);
		BufferedReader rd = null;
		
		try {
			rd = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String line;
		StyledDocument doc = getStyledDocument();
		SimpleAttributeSet fBold = new SimpleAttributeSet();
		StyleConstants.setBold(fBold, true);
		StyleConstants.setFontFamily(fBold, "Arial");
		try {
			while ((line = rd.readLine()) != null) {
				String[] lineSplit = line.split(" ");
				//for(int j = 0 ; j < lineSplit.length ; j++)
				//	System.out.println(lineSplit[j]);
				if(	lineSplit[0].contains("ENTRY") || 
					lineSplit[0].contains("NAME") || 
					lineSplit[0].contains("DEFINITION") || 
					lineSplit[0].contains("ORTHOLOGY") || 
					lineSplit[0].contains("ORGANISM") || 
					lineSplit[0].contains("PATHWAY") || 
					lineSplit[0].contains("MODULE") || 
					lineSplit[0].contains("BRITE") || 
					lineSplit[0].contains("POSITION") || 
					lineSplit[0].contains("MOTIF") ||
					lineSplit[0].contains("DBLINKS") ) {
					try {
						doc.insertString(doc.getLength(), lineSplit[0], fBold );
					} catch (BadLocationException e) {		e.printStackTrace();	}
					for(int i = 1 ; i < lineSplit.length ; i++){
						try {
							doc.insertString(doc.getLength(), " "+lineSplit[i], null );
						} catch (BadLocationException e) {	e.printStackTrace();	}
					}
					try {
						doc.insertString(doc.getLength(), "\n", null );
					} catch (BadLocationException e) {		e.printStackTrace();	}
				} else {
				    try {
						doc.insertString(doc.getLength(), line+"\n", null );
					} catch (BadLocationException e) {		e.printStackTrace();	}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			rd.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		setEditable(false);
	}
	 
	/**
	 * Opens a new window with the reaction image
	 */
	public void showGif() {
		
		JFrame reacGifWindow = new JFrame ();
		reacGifWindow.setTitle("Reaction : "+this.reaction);
		reacGifWindow.setSize(500, 500);
		reacGifWindow.setLocationRelativeTo(null);
		reacGifWindow.setVisible(true);
		
		JLabel reacGif = new JLabel (); 
		ImageIcon defaultIcon = new ImageIcon(".\\KEGG files\\Files image\\"+this.reaction+".gif");
		reacGif.setIcon(defaultIcon);
		
		JScrollPane scrollReacGIF = new JScrollPane(reacGif);
		reacGifWindow.setSize(defaultIcon.getIconWidth()+29, defaultIcon.getIconHeight()+68);
		reacGifWindow.getContentPane().add(scrollReacGIF);
		
	}
	 
}

