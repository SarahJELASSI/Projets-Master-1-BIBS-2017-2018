import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.FileNotFoundException;
import java.util.List;

/**
 * Loads the generic metabolic pathway map desired. 
 * Records all the needed datas about the .conf file of the map desired. 
 * 
 * @author SarAlice Laboratory�
 * @version 2.718
 */

public class GenericMetaboPW implements Loadable{

	// Attributes
	
	/**
	 * The image where the .png of the generic metabolic pathway will be displayed.
	 */
	static BufferedImage image = null;
	
	/**
	 * The map ID of the generic metabolic pathway.
	 */
	private String map_id;
	
	/**
	 * The hashtable of the .conf the specific metabolic pathway.
	 */
	private Hashtable<String, List<String>> dict;
	
    // Constructors
	
	/**
	 * Constructor of the generic metabolic pathway.
	 * @param species
	 * @param map_id
	 */
	public GenericMetaboPW(String species, String map_id)
	{
		this.map_id = map_id;
		setParam ( species,  map_id) ;
	}	
		
	// Methods 
	
	/**
	 * Set the parameters for the generic metabolic pathway and update it.
	 * @param species
	 * @param map_id
	 */
	public void setParam (String species, String map_id) {
		
		this.map_id = map_id;
		
		if (!localLoad()) internetLoad();
		
		String fileName = ".\\KEGG files\\Files conf\\map"+map_id+".conf";

		try {
			this.dict=generateDict(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}
						
	}
	
	/**
	 * Check if the wanted information are present locally 
	 * @return boolean: file is saved locally or not
	 */
	
	public boolean localLoad () {
		
		String fileName = ".\\KEGG files\\Files conf\\map"+map_id+".conf";
		File file = new File(fileName);

		if (!file.exists()) {
			return false;
		}
		else return true;
	}
	
	/**
	 * Download the wanted files on the Internet.
	 */
	public void internetLoad (){

		URL url3;
		try {
			// get URL content
			url3 = new URL("http://rest.kegg.jp/get/map"+map_id+"/conf");
			URLConnection conn = url3.openConnection();

			// open the stream and put it into BufferedReader
			BufferedReader br = new BufferedReader(
							   new InputStreamReader(conn.getInputStream()));

			String inputLine;

			//save to this filename
			String fileName = ".\\KEGG files\\Files conf\\map"+map_id+".conf";
			File file = new File(fileName);

			if (!file.exists()) {
				file.createNewFile();
			}

			//use FileWriter to write file
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			while ((inputLine = br.readLine()) != null) {
				bw.write(inputLine);
				bw.write ("\n");
			}

			bw.close();
			br.close();
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	/**
	 * Returns the image of the generic metabolic pathway.
	 * @return image: the image of the generic metabolic pathway.
	 */
	BufferedImage getImage()
	{
		return image;
	}
	
	
	/** 
	 * Generate and returns the hashtable of the .conf of the generic metabolic pathway
	 * 
	 * @param filename : the .conf needed for the Hashtable 
	 * @return Hashtable<String,List<String>> for the Hashtable 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public Hashtable<String,List<String>> generateDict(String filename) throws FileNotFoundException, IOException  {
				
	    String line;
	    Hashtable<String,List<String>> dict=new Hashtable<String,List<String>>();
	    File file = new File(filename);
		
		FileReader fr = new FileReader(file.getAbsoluteFile());
		BufferedReader br = new BufferedReader(fr);
		
		// Reading the .conf line by line 
		while ((line = br.readLine()) != null){
			
			//Selecting the right line
			Pattern pattern = Pattern.compile("(rect(.+,.+))\t(/dbget-bin/www_bget?.+)\t((.+),(.+),(.+))");
			Matcher matcher = pattern.matcher(line);
		    
			while(matcher.find()) {

			    List<String> listReaction = new ArrayList<String>();
				String cle = matcher.group(2);
				cle=cle.replace("(","");
				cle=cle.replace(")","");
				cle=cle.replace("\t","");

				//Split the url in order to find the reaction 
				
				String url =matcher.group(3);
				String[] sep_interro = url.split("\\?");
				String[] sep_plus = sep_interro[1].split("\\+");
				for(int i = 0; i<sep_plus.length;i++) {
					if(sep_plus[i].contains("R")) {
						listReaction.add(sep_plus[i]);
					}
				}

				Pattern pattern2 = Pattern.compile("(.+),(.+) (.+),(.+)");
				Matcher matcher2 = pattern2.matcher(cle);
				while(matcher2.find()) {
					   dict.put(matcher2.group(1)+" "+matcher2.group(2), listReaction);
				}
		    }
		}
		
		br.close();
		return(dict);			
	}
	
	/**	
	 * Returns the hashtable of the .conf
	 * @return Hashtable <String,List<String>> : the hashtable of the .conf
	 */
	public Hashtable <String,List<String>> getDict () {
		return(this.dict);
	}
	
}
