import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import javax.swing.ImageIcon;
import javax.swing.JTextField;

/**
 * The Mouselistener of the metabolic pathway map
 * 
 * @author SarAlice Laboratory�
 * @version 8.31
 */

public class MetaboPWMouseListener implements MouseListener {
	
	// Attributes
	
	/**
	 * The specific metabolic pathway where the MouseListener is applied 
	 * @see SpecificMetaboPW
	 */
	private SpecificMetaboPW voieMetaboSpe; 
	
	/**
	 * The list of the gene involved in the reaction.
	 * @see ListGene
	 */
	private ListGene listGene;
	
	/**
	 * The ReacInfoText where the informations about a reaction
	 * selected will be displayed .
	 * @see ReacInfoText
	 */
	private ReacInfoText rit_reacInfo;
	
	/**
	 * The species ID of the genomic map	
	 */
	private JTextField t_species1;
	
	/**
	 * The gene ID of the genomic map.	 
	 */
	private JTextField t_gene;
	
	/**
	 * The species ID of the metabolic pathway.	 
	 */
	private JTextField t_species2;
	
	/**
	 * The map ID of the metabolic pathway.	 
	 */
	private JTextField t_map;
	
	// Constructor
	/**
	 * The constructor of MetaboPWMouseListener
	 * 
	 * @param voieMetaboSpe
	 * @param listGene
	 * @param rit_reacInfo
	 * @param t_species2
	 * @param t_species1
	 * @param t_gene
	 * @param t_map
	 */
	public MetaboPWMouseListener (	SpecificMetaboPW voieMetaboSpe,
									ListGene listGene,
					 				ReacInfoText rit_reacInfo,
					 				JTextField t_species2,
					 				JTextField t_species1,
					 				JTextField t_gene,
					 				JTextField t_map){
		 
		 this.listGene		= listGene;
		 this.rit_reacInfo	= rit_reacInfo;	 
		 this.t_species2	= t_species2;
		 this.t_map			= t_map;
		 this.t_species1	= t_species1;
		 this.t_gene		= t_gene;
		 this.voieMetaboSpe = voieMetaboSpe;
	 }
	 
	/**
	 * Invoked when a mouse button has been released on a component.
	 */
	 public void mouseReleased(MouseEvent arg0) {}
	 
	/**
	 * Invoked when a mouse button has been pressed on a component.
	 */
	 public void mousePressed(MouseEvent arg0) {}
	 
	/**
	 * Invoked when the mouse exits a component.
	 */
	 public void mouseExited(MouseEvent arg0) {}
	 
	/**
	 * Invoked when the mouse enters a component.
	 */
	 public void mouseEntered(MouseEvent arg0) {}
	 
	 /**
	  * Invoked when the mouse button has been clicked (pressed and released) on a component.
	  */
	 public void mouseClicked(MouseEvent arg0) {
		 EstDansRectangleVert(t_species2,t_map,t_species1, t_gene, arg0, arg0.getX(),arg0.getY());
	 }
	 
	 /**
	  * Does all the things to do when the user click on a green rectangle, that is to say :
	  * -refresh the JTextArea of ReacInfo, and the JList of ListReac
	  * -draws red rectangles around the green rectangle
	  *  
	  * @param t_species2
	  * @param t_map
	  * @param t_species1
	  * @param t_gene
	  * @param arg0
	  * @param x
	  * @param y
	  */
	 public void EstDansRectangleVert(  JTextField t_species2,
				 						JTextField t_map,
				 						JTextField t_species1,
				 						JTextField t_gene,
			 						    MouseEvent arg0,
			 						    int x, 
			 						    int y) {
		 
		 SpecificMetaboPW voieMetTmpSpe = new SpecificMetaboPW(t_species2.getText(),t_map.getText());
		 GenericMetaboPW voieMetTmpGen  = new GenericMetaboPW(t_species2.getText(),t_map.getText());

		 Hashtable<String,List<String>> dictTmpSpe = voieMetTmpSpe.getDict();
		 Hashtable<String,List<String>> dictTmpGen = voieMetTmpGen.getDict();

		
		 for(Map.Entry m:dictTmpSpe.entrySet()){

			// 1) Separe the two pixels forming the key. Their type is String
			String pixels = (String)m.getKey();
			Pattern pattern3 = Pattern.compile("(.+) (.+)");
			Matcher matcher3 = pattern3.matcher(pixels);
			int pixel1=0, pixel2=0;
			
			// 2) Converting each of the pixels in Int
			while(matcher3.find()) {
				String Pixel1 = matcher3.group(1);
				Pixel1=Pixel1.replace(" ",""); 
				pixel1=Integer.parseInt(Pixel1);
				pixel2=Integer.parseInt(matcher3.group(2));
			}

			// 3) Check if for each of the key if the mouse is contained in the corresponding rectangle 
			if (Contient(pixel1, pixel2, x, y)){
				List<String> list_genetmp =(List<String>) m.getValue();
				listGene.reload(list_genetmp);
				
				for(Map.Entry m2:dictTmpGen.entrySet()) {
					if (m.getKey().equals(m2.getKey())) 
					{
						List<String> list_reac=(List<String>) m2.getValue();
						String reaction=list_reac.get(0);
						rit_reacInfo.reload(reaction);
					}
				}

				Graphics2D g2d = voieMetaboSpe.getImage().createGraphics();
				int thickness = 3;
				g2d.setStroke(new BasicStroke(thickness));
				
				// Draw on the buffered image
				g2d.setColor(Color.red);
				g2d.drawRect(pixel1, pixel2, 46, 16);
				g2d.dispose();
				voieMetaboSpe.setIcon(new ImageIcon(voieMetaboSpe.getImage()));
			}
				
			if ((t_species1.getText().isEmpty()) && (t_gene.getText().isEmpty())) {
				listGene.setSelectedIndex(0);
			}
		}
	}
	 
	/**
	 * Check and returns true if the cursor is in a green rectangle 
	 * @param pixel1
	 * @param pixel2
	 * @param x
	 * @param y
	 * @return a boolean
	 */
	public boolean Contient(int pixel1, int pixel2, int x, int y) {
		return(  ( (pixel1<x) && (x<pixel1+46) )  &&  ( (pixel2<y) && (y<pixel2+16) )  );
	}
}
