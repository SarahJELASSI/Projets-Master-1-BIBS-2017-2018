import javax.swing.JTextField;
import javax.swing.SwingWorker;

/**
 * Performs the lengthy GUI-interactions of reloading the Swingbox in a background thread. 
 * 
 * @author SarAlice Laboratory�
 * @version 3.14
 * @see SwingBoxGene
 */

public class BrowserWorker extends SwingWorker <Void,Void> {
	
	// Attributes 
	
	/**
	 * The object SwingBoxGene where the genomic map will be showed.
	 * @see SwingBoxGene 
	 */
	private SwingBoxGene swingbox;
	
	/**
	 * The species ID of the genomic map.
	 */
	private JTextField t_species1;
	
	/**
	 * The gene ID of the genomic map.
	 */
	private JTextField t_gene;
	
	
	//Constructor
	
	/**
	 * Constructor of the BrowserWorker
	 * 
	 * @param swingbox
	 * @param t_species1
	 * @param t_gene
	 */
	public BrowserWorker(	SwingBoxGene swingbox,	
							JTextField t_species1,
							JTextField t_gene) {

		 this.swingbox= swingbox; 
		 this.t_species1= t_species1; 
		 this.t_gene= t_gene; 
		 
	}
	
	// Methods 
	
	@Override
	/**
	 * Reload the Swingbox in a background thread.
	 */
	public Void doInBackground() {

		//Reload of the swingbox in a background thread
		swingbox.setParam(t_species1.getText(),t_gene.getText());
		
		return null;
	}

	@Override
	/**
	 * Executed on the Event Dispatch Thread after the doInBackground method is finished.
	 * The default implementation does nothing.
	 */
	public void done () {
	}
		

}