import java.io.File;
import java.io.IOException;

/**
 * Interface class that has the following methods
 * 
 * @author SarAlice Laboratory�
 * @version 065.046.090.032.060.051
 */

public class MainKEGGBrowserFinal {
	
	/**
	 * Main method of the KEGG Browser by the SarAlice Laboratory�
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		
		final String dir = System.getProperty("user.dir");
		
		File file = new File(dir+"\\KEGG files");  
		if (file.mkdirs()) System.out.println("Dir is created!");
		else    System.out.println("Dir already exists.");
		
		file = new File(dir+"\\KEGG files\\Files conf");
		if (file.mkdirs()) System.out.println("Dir is created!");
		else    System.out.println("Dir already exists.");
		
		file = new File(dir+"\\KEGG files\\Files image");
		if (file.mkdirs()) System.out.println("Dir is created!");
		else    System.out.println("Dir already exists.");
		
		file = new File(dir+"\\KEGG files\\Files txt");
		if (file.mkdirs()) System.out.println("Dir is created!");
		else    System.out.println("Dir already exists.");
		
		
		MainWindow browser = new MainWindow();
		browser.setVisible(true);
	}
}


