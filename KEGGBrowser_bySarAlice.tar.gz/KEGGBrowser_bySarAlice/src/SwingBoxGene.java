import org.fit.cssbox.swingbox.BrowserPane;
import java.net.MalformedURLException;
import java.net.URL ;
import java.io.IOException;
/**
 *
 * Displays the genome map desired (written in the top fields or clicked on the "involve gene(s)" list. 
 *
 * @author SarAlice Laboratory�
 * @version 1.38
 *
 */
public class SwingBoxGene extends BrowserPane{
	 
	// Attributes
	 
	// Constructors
	
	/**
	 * Constructor SwingBoxGene
	 */
	public SwingBoxGene () { 
			
	}

	// Methods 
	
	/**
	 * Updates the genome map.
	 * 
	 * @param species
	 * @param gene
	 */
	
	public void setParam(String species, String gene) {
		try {
			setPage(new URL("http://www.genome.jp/kegg-bin/show_genomemap?ORG="+species+"&ACCESSION="+gene));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}