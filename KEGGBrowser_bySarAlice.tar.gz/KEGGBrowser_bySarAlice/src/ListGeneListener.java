import java.awt.Cursor;
import java.util.Hashtable;
import java.util.List;

import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * The ListSelectionListener of the list of the gene involved in the reaction.
 * 
 * @author SarAlice Laboratory�
 * @version 4.6692
 * @see ListGene
 */
public class ListGeneListener  implements ListSelectionListener {

	// Attributes
	/**
	 * The temporary list of the gene involved in the reaction.
	 * @see ListGene
	 */
	private JList<String> listGene;
	
	/**
	 * The swingbox where the genomic map is displayed.
	 * @see SwingBoxGene
	 */
	private SwingBoxGene swingbox;
	
	/**
	 * The species ID of the genomic map.
	 */
	private JTextField species1;
	
	/**
	 * The species ID of the metabolic pathway.
	 */
	private JTextField species2;
	
	/**
	 * The gene ID of the genomic map.
	 */
	private JTextField gene;
	
	/**
	 * The SwingWorker who reload the gene information and the list of reactions
	 * where the gene is involved.
	 * @see GenomeWorker
	 */
	private GenomeWorker genomeWorker;
	
	/**
	 * The SwingWorker who reload the genomic map.
	 * @see BrowserWorker
	 */
	private BrowserWorker browserWorker;
	
	/**
	 * The GeneInfoText where the gene information will be displayed .
	 */
	private GeneInfoText git_geneInfo;
	
	/**
	 * The list of Reactions where the gene is involved.
	 */
	private ListReact listReact;
	
	
	// Constructor
	/**
	 * Constructor of the Listener. 
	 * 
	 * @param listGene
	 * @param swingbox
	 * @param species1
	 * @param species2
	 * @param gene
	 * @param git_geneInfo
	 * @param listReact
	 */
	public ListGeneListener(	JList<String> listGene,
								SwingBoxGene swingbox,
								JTextField species1,
								JTextField species2,
								JTextField gene,
								GeneInfoText git_geneInfo,
								ListReact listReact) {
		
		this.listGene = listGene;
		this.swingbox = swingbox;
		this.species1 = species1;
		this.species2 = species2;
		this.gene = gene;
		this.git_geneInfo = git_geneInfo;
		this.listReact = listReact;
		
	}
	
	@Override
	/**
	 * Called whenever the value of the selection changes.
	 * When the List is clicked on, change the genomic map, the gene informations and the list of reactions
	 * where the gene is involved.
	 */
	public void valueChanged(ListSelectionEvent e) {
		
		this.listGene.setCursor(new Cursor(Cursor.WAIT_CURSOR));
		
		if(!listGene.isSelectionEmpty()) {
			this.species1.setText(this.species2.getText());
			this.gene.setText(this.listGene.getSelectedValue());
			genomeWorker = new GenomeWorker (git_geneInfo,listReact);
			browserWorker = new BrowserWorker (swingbox,species1, gene);
			genomeWorker.execute();
			try {
				Thread.sleep(500);					// Threads's Synchronization
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			browserWorker.execute();
		}
		
		this.listGene.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
}
