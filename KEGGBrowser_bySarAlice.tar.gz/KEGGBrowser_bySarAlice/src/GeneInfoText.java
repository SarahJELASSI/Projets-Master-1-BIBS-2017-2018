import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

import java.io.IOException;
import java.net.MalformedURLException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.URLConnection;

/**
 * Display the Gene Informations of the gene entered if the field "Gene ID" 
 * or the gene selected in the "Involves gene(s)" list
 * 
 * @author SarAlice Laboratory�
 * @version 6.0221409e+23
 */

public class GeneInfoText extends JTextPane implements Loadable {

	// Attributes
	
	/**
	 * The species ID of the genomic map.
	 */
	private JTextField species;
	
	/**
	 * The gene ID of the genomic map.
	 */
	private JTextField gene;
	
	// Constructor 
	/**
	 * Constructor of the object GeneInfoText.
	 * 
	 * @param species
	 * @param gene
	 */
	public GeneInfoText (JTextField species, JTextField gene) {

		this.species = species; 
		this.gene = gene;

	}
			
	// Methods
	/**
	 * Reload the Gene Informations based on the new studied gene.
	 * @return long
	 */
	public long reload () {
		loadFiles();
		setTxt();
		return 0;
	}
	
	/**
	 * Set the right parameters for the GeneInfoText.
	 * @return long
	 */
	public long setParam (String species, String gene) {
		
		this.species.setText(species); 
		this.gene.setText(gene);
		return 0; 
		
	}
		
	
	/**
	 * Check if the wanted information are present locally 
	 * @return boolean: file is saved locally or not
	 */
	public boolean localLoad () {
		
		String fileName = ".\\KEGG files\\Files txt\\"+species.getText()+"_"+gene.getText()+".txt"; //A TERMES REGARDER LE CHEMIN RELATIF
		File file = new File(fileName);

		if (!file.exists()) {
			return false;
		}
		else return true;
		
	}
	
	/**
	 * Download the wanted files on the Internet.
	 */
	public void internetLoad () {
		URL url;
		try {
			// get URL content
			url = new URL("http://rest.kegg.jp/get/"+species.getText()+":"+gene.getText());
			URLConnection conn = url.openConnection();

			// open the stream and put it into BufferedReader
			BufferedReader br = new BufferedReader(
							   new InputStreamReader(conn.getInputStream()));

			String inputLine;

			//save to this filename
			String fileName = ".\\KEGG files\\Files txt\\"+species.getText()+"_"+gene.getText()+".txt";
			File file = new File(fileName);

			if (!file.exists()) {
				file.createNewFile();
			}

			//use FileWriter to write file
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);

			while ((inputLine = br.readLine()) != null) {
				bw.write(inputLine);
				bw.write ("\n");
			}
			bw.close();
			br.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			JFrame fenetre_erreur= new JFrame();
			ImageIcon Icon = new ImageIcon("try_and_catch.jpg");
			
			JOptionPane.showMessageDialog(fenetre_erreur, 
			         "The Gene ID does not exist or you do not have the Internet",
			         " Error ",
			         JOptionPane.WARNING_MESSAGE,
			         Icon);
			e.printStackTrace();
		}
	}
	
	/**
	 * Sets the text from the txt files to the TextArea
	 */
	public void setTxt() {
		
		setText("");
		String filename = ".\\KEGG files\\Files txt\\"+species.getText()+"_"+gene.getText()+".txt" ;
		
		File file = new File(filename);
		BufferedReader rd = null;
		try {
			rd = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String line;
		StyledDocument doc = getStyledDocument();
		SimpleAttributeSet fBold = new SimpleAttributeSet();
		StyleConstants.setBold(fBold, true);
		StyleConstants.setFontFamily(fBold, "Default");
		try {
			while ((line = rd.readLine()) != null) {
				String[] lineSplit = line.split(" ");
				if(	lineSplit[0].contains("ENTRY") || 
					lineSplit[0].contains("NAME") || 
					lineSplit[0].contains("DEFINITION") || 
					lineSplit[0].contains("ORTHOLOGY") || 
					lineSplit[0].contains("ORGANISM") || 
					lineSplit[0].contains("PATHWAY") || 
					lineSplit[0].contains("MODULE") || 
					lineSplit[0].contains("BRITE") || 
					lineSplit[0].contains("POSITION") || 
					lineSplit[0].contains("MOTIF") ||
					lineSplit[0].contains("DBLINKS") ) {
					try {
						doc.insertString(doc.getLength(), lineSplit[0], fBold );
					} catch (BadLocationException e) {		e.printStackTrace();	}
					for(int i = 1 ; i < lineSplit.length ; i++){
						try {
							doc.insertString(doc.getLength(), " "+lineSplit[i], null );
						} catch (BadLocationException e) {	e.printStackTrace();	}
					}
					try {
						doc.insertString(doc.getLength(), "\n", null );
					} catch (BadLocationException e) {		e.printStackTrace();	}
				} else if(	lineSplit[0].equals("") ) {
					try {
						doc.insertString(doc.getLength(), "\t", fBold );
					} catch (BadLocationException e) {		e.printStackTrace();	}
					for(int i = 12 ; i < lineSplit.length ; i++){
						try {
							doc.insertString(doc.getLength(), " "+lineSplit[i], null );
						} catch (BadLocationException e) {	e.printStackTrace();	}
					}
					try {
						doc.insertString(doc.getLength(), "\n", null );
					} catch (BadLocationException e) {		e.printStackTrace();	}
				} else {
				    try {
						doc.insertString(doc.getLength(), line+"\n", null );
					} catch (BadLocationException e) {		e.printStackTrace();	}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			rd.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		setEditable(false);
	}
}
