import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
public class MapInfo {
	
	JTextField map ; 
	
	public MapInfo (JTextField map) {
		this.map=map;
	}
	public void getInfoMap (JTextField map){
		
		System.out.println (map.getText());
		if (map.getText().contains("zaharia")) {
			URI uri = URI.create("https://www.lri.fr/~zaharia/");
			try {
				Desktop.getDesktop().browse(uri);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else if (map.getText().contains("descorps-declere")) {
			URI uri = URI.create("https://research.pasteur.fr/fr/member/stephane-descorps-declere/");
			try {
				Desktop.getDesktop().browse(uri);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		else {
			URI uri = URI.create("http://www.kegg.jp/dbget-bin/www_bget?map"+map.getText());
			try {
				Desktop.getDesktop().browse(uri);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
