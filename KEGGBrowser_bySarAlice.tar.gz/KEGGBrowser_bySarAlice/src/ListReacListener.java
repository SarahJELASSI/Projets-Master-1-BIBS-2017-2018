import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * The ListSelectionListener of the list of reactions
 * where the gene is involved.
 * 
 * @author SarAlice Laboratory�
 * @version 43252003274489856000
 * @see ListGene
 */

public class ListReacListener implements ListSelectionListener  {
	
	// Attributes
	/**
	 * The temporary list of reactions
     * where the gene is involved.
	 * @see ListGene
	 */
	private JList<String> listReac; 
	
	/**
	 * The specific metabolic pathway that will reload once the list clicked.
	 * @seeSpecificMetaboPW
	 */
	private SpecificMetaboPW voieMetabo_spe;

	/**
	 * The list of the gene involved in the reaction.
	 * @see ListGene
	 */
	private ListGene listGene;
	
	/**
	 * The ReacInfoText where the informations about a reaction
	 * selected will be displayed .
	 * @see ReacInfoText
	 */
	private ReacInfoText infoReac;
	
	/**
	 * The species ID of the metabolic pathway.
	 */
	private JTextField t_species2;
	
	/**
	 * The map ID of the metabolic pathway.
	 */
	private JTextField t_map;
	
	// Constructor 
	
	/**
	 * Constructor of the Listener.
	 * 
	 * @param listReac
	 * @param voieMetabo_spe
	 * @param infoReac
	 * @param t_species2
	 * @param t_map
	 */
	public ListReacListener( JList<String> listReac,
							 SpecificMetaboPW voieMetabo_spe,
							 ListGene listGene,
							 ReacInfoText infoReac,
							 JTextField t_species2,
							 JTextField t_map ) {
		
		this.listReac 		= listReac; 
		this.voieMetabo_spe	= voieMetabo_spe;
		this.listGene		= listGene;
		this.infoReac 		= infoReac;
		this.t_species2 	= t_species2;
		this.t_map			= t_map;
		
	}
	
	@Override
	/**
	 * Called whenever the value of the selection changes.
	 * When the List is clicked on, change the metabolic pathway and the reaction informations
	 */
	public void valueChanged(ListSelectionEvent e) {

		this.listReac.setCursor(new Cursor(Cursor.WAIT_CURSOR));

		if(!listReac.isSelectionEmpty()) {	
		
			List<String> list_tempo = new ArrayList<String>();
			String[] temp = listReac.getSelectedValue().split(" @");
			
			String reaction = temp[0];
			this.t_species2.setText( temp[1].substring(1,4) );
			this.t_map.setText( temp[1].substring(4,9) );
			
			infoReac.reload(reaction);
			this.voieMetabo_spe.setParam( t_species2.getText(),t_map.getText());
			SpecificMetaboPW voieMetTmpSpe = new SpecificMetaboPW(t_species2.getText(),t_map.getText());
			 GenericMetaboPW voieMetTmpGen  = new GenericMetaboPW(t_species2.getText(),t_map.getText());

			 Hashtable<String,List<String>> dictTmpSpe = voieMetTmpSpe.getDict();
			 Hashtable<String,List<String>> dictTmpGen = voieMetTmpGen.getDict();

			 for(Map.Entry m:dictTmpGen.entrySet()){

				// 1) Separe the two pixels forming the key. Their type is String
				String pixels = (String)m.getKey();
				Pattern pattern3 = Pattern.compile("(.+) (.+)");
				Matcher matcher3 = pattern3.matcher(pixels);
				int pixel1=0, pixel2=0;
				
				// 2) Converting each of the pixels in Int
				while(matcher3.find()) {
					String Pixel1 = matcher3.group(1);
					Pixel1=Pixel1.replace(" ",""); //enlever l'espace du premier pixel avant de le convertir en int
					pixel1=Integer.parseInt(Pixel1);
					pixel2=Integer.parseInt(matcher3.group(2));
				}
				
				ArrayList<String> react = (ArrayList<String>)m.getValue();
				for(int i = 0; i< react.size(); i++ ){
					if(reaction.contains(react.get(i))){
						for(Map.Entry mSpe:dictTmpSpe.entrySet())
							if (m.getKey().equals(mSpe.getKey())) 
								listGene.reload((List<String>)mSpe.getValue());
						
						Graphics2D g2d = voieMetabo_spe.getImage().createGraphics();
						int thickness = 3;
						g2d.setStroke(new BasicStroke(thickness));
						
						// Draw on the buffered image
						g2d.setColor(Color.blue);
						g2d.drawRect(pixel1, pixel2, 46, 16);
						g2d.dispose();
						voieMetabo_spe.setIcon(new ImageIcon(voieMetabo_spe.getImage()));

					}
				}
			 }
		}
		this.listReac.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
}
