/**
 * Interface class that has the following methods
 * 
 * @author SarAlice Laboratory�
 * @version 9.806 65
 */
public interface Loadable {

	/**
	 * Check if the boolean returned by localLoad is true, if not apply internetLoad.
	 */
	public default void loadFiles() {
		if(!localLoad ()) internetLoad();
	}
	
	public boolean localLoad ();
	
	public void internetLoad ();
}
