import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 * Display the list of the gene involved in the reaction.
 * 
 * @author SarAlice Laboratory�
 * @version 0.57721
 */
public class ListGene extends JList<String> {

	// Attributes 
	/**
	 * The temporary list where gene are saved.
	 */
	private List<String> list_genetmp;
	
	// Constructor 
	/**
	 * Constructor list of the gene involved in the reaction.
	 * @param t_species2
	 * @param t_map
	 * @param list_genetmp
	 */
	public ListGene ( JTextField t_species2, JTextField t_map, List<String> list_genetmp) {
		
		this.list_genetmp=list_genetmp;
	}

	// Methods 
	/**
	 * Reload the list of the gene involved in the reaction.
	 */
	public void reload(List<String> list_genetmp) {
		
		DefaultListModel<String> model=new DefaultListModel<String>();
		for (int i=0; i<list_genetmp.size(); i++) {
			model.addElement(list_genetmp.get(i));
		}
		this.setModel(model);
	}
	
}
