import javax.swing.SwingWorker;

/**
 * Performs the lengthy GUI-interactions of reloading the Gene Informations and the List of Reactions
 * where the gene is involved in a background thread. 
 * 
 * @author SarAlice
 * @version 0.42
 * @see GeneInfoText , ListReact
 */

public class GenomeWorker extends SwingWorker <Void,GeneInfoText> {
	
	// Attributes 
	
	/**
	 * The object GeneInfoText where the Gene Informations will be displayed.
	 * @see GeneInfoText 
	 */
	private GeneInfoText git_geneInfo;
	
	/**
	 * The object ListReact where the List of Reactions
	 * where the gene is involved will be displayed.
	 * @see ListReact 
	 */
	private ListReact listReact;
	
	// Methods 
	
	/**
	 * Constructor of the GenomeWorker
	 * 
	 * @param git_geneInfo
	 * @param listReact
	 */
	public GenomeWorker(GeneInfoText git_geneInfo,
			 			ListReact listReact ) {
		 
		 this.listReact= listReact; 
		 this.git_geneInfo=git_geneInfo; 
		 
	}

	@Override
	/**
	 * Reload the Gene Informations and the List of Reactions
	 * where the gene is involved in a background thread.
	 */
	public Void doInBackground() {
		
		//Reload of the gene's info and the list of reaction in a background thread
		git_geneInfo.reload();
		listReact.reload();
		
		return null;
	}

	@Override
	/**
	 * Executed on the Event Dispatch Thread after the doInBackground method is finished.
	 * The default implementation does nothing.
	 */
	public void done () {
	}
	
	

}