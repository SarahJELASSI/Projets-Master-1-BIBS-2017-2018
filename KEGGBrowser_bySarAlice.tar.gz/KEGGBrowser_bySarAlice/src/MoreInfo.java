import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Displays a frame with some pieces of informations about KEGG Browser application functionalities 
 * 
 * @author SarAlice Laboratory�
 * @version 0.69
 */

public class MoreInfo extends JTextArea implements ActionListener, WindowListener {
	
	// Attributes
	JTextArea	moreInfo = new JTextArea();
	JButton 	b_update = new JButton();
	AudioClip 	ac;
	
	// Constructor 
	/**
	 * Constructor of MoreInfo
	 */
	public MoreInfo () {

		JFrame moreWindow = new JFrame ();
		moreWindow.setTitle("More KEGG Browser by SarAlice");
		moreWindow.setSize(800, 300);
		moreWindow.setLocationRelativeTo(null);
		moreWindow.setVisible(true);
		
		setTxt();
		
		JScrollPane scrollVersionText = new JScrollPane(moreInfo);
		JButton b_update = new JButton("Update :)");
		JPanel morePanel = new JPanel ();
		
		morePanel.setLayout(new BoxLayout(morePanel, BoxLayout.PAGE_AXIS));
		morePanel.add(scrollVersionText);
		morePanel.add(b_update);
		
		moreWindow.getContentPane().add(morePanel);

		String f = new String("song.wav");
		try {
			URL url = new File(f).toURI().toURL();
			ac = Applet.newAudioClip(url);
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
		b_update.addActionListener(this);
		moreWindow.addWindowListener(this);
	}
	
	// Methods
	
	/**
	 * Sets the text from the txt files to the TextArea
	 */
	private void setTxt() {
		Font f = new Font("Arial", Font.PLAIN, 16);
		moreInfo.setFont(f);
		moreInfo.setText("");
		String filename = "More_KEGG.txt" ;
		
		File file = new File(filename);
		BufferedReader rd = null;
		try {
			rd = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String line;
		try {
			while ((line = rd.readLine()) != null)
				moreInfo.append(line + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			rd.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		moreInfo.setEditable(false);
	}

	@Override
	/**
	 * Invoked when an action on the button "Update " occurs.
	 */
	public void actionPerformed(ActionEvent e) {
		ac.play();
	}

	@Override
	/**
	 * Invoked when the user attempts to close the window from the window's system menu.
	 */
	public void windowClosing(WindowEvent e) {
		ac.stop();
	}

	@Override
	/**
	 * Invoked when the Window is set to be the active Window.	 
	 */
	public void windowActivated(WindowEvent e) {}

	@Override
	/**
	 * Invoked when a window has been closed as the result of calling dispose on the window.
	 */
	public void windowClosed(WindowEvent e) {}

	@Override
	/**
	 * Invoked when a Window is no longer the active Window.
	 */
	public void windowDeactivated(WindowEvent e) {}

	@Override
	/**
	 * Invoked when a window is changed from a minimized to a normal state.
	 */
	public void windowDeiconified(WindowEvent e) {}

	@Override
	/**
	 * Invoked when a window is changed from a normal to a minimized state.
	 */
	public void windowIconified(WindowEvent e) {}

	@Override
	/**
	 * Invoked the first time a window is made visible.
	 */
	public void windowOpened(WindowEvent e) {}
}
