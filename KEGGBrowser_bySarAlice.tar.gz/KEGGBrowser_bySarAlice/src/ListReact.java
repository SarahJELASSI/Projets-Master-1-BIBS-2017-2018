import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JTextField;

/**
 * Display list of reactions where the gene is involved.
 * 
 * @author SarAlice Laboratory�
 * @version 6.626070040e-34
 */

public class ListReact extends JList<String> {
	
	// Attributes 
	
	/**
	 * The species ID of the genomic map.
	 */
	private JTextField species;
	/**
	 * The gene ID of the genomic map.
	 */
	private JTextField gene;

		
	// Constructor 
	/**
	 * Constructor of the list of reactions where the gene is involved.
	 * @param species
	 * @param gene
	 */
	public ListReact (	JTextField species,
						JTextField gene ) {
		
		this.species=species; 
		this.gene=gene; 

	}
	
	// Methods 
	
	/**
	 * Reload the list of reactions where the gene is involved.
	 * @return long 
	 */
	public long reload() {
		System.out.println("ListReact : Loading beginning ");
		List<String> list_tempo = new ArrayList<String>();
		
		String filename = ".\\KEGG files\\Files txt\\"+species.getText()+"_"+gene.getText()+".txt" ;
		
		File file = new File(filename);
		BufferedReader rd = null;
		
		try {
			rd = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		String line;
		try {
			while ((line = rd.readLine()) != null) {
				
				String [] temp ;
				
				if (line.contains("PATHWAY") ){
					temp  = line.split("\\b");
					list_tempo.add(temp[2]);
				}

				else if (line.contains(species.getText()+"0") && !line.contains(":"+species.getText())){
					temp = line.split("\\b");			
					list_tempo.add(temp[1]);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		List<String> listReact = new ArrayList<String>();
		
		DefaultListModel<String> model=new DefaultListModel<String>();
		for (int i=0; i<list_tempo.size();i++) {
			String map_id2 = list_tempo.get(i);
			map_id2= map_id2.substring(3,8);

			listReact = getReaction(map_id2);
			
			for(int j = 0 ; j< listReact.size() ; j++) {
				model.addElement(listReact.get(j) + " @ " + list_tempo.get(i));
				}
			
			}
			this.setModel(model);
			
			try {
				rd.close();
			} catch (IOException e) {	e.printStackTrace();
			}
			System.out.println("ListReact : Loading end ");
			return 0;
	}
		

	/**
	 * Returns a list of map ID needed in order to create the final 
	 * list of reactions where the gene is involved
	 * @param list_map_id
	 * @return List<String> : the list of map ID
	 */
	public List<String> getReaction (String list_map_id){

		List<String> listReact = new ArrayList<String>(); 
		
		List<String> cle = new ArrayList<String>(); 
		List<String> react = new ArrayList<String>();
		
		SpecificMetaboPW voieMetTmpSpe = new SpecificMetaboPW(species.getText(),list_map_id);
		GenericMetaboPW voieMetTmpGen = new GenericMetaboPW(species.getText(),list_map_id);

		Hashtable<String,List<String>> dicoTmpSpe = voieMetTmpSpe.getDict();
		Hashtable<String,List<String>> dicoTmpGen = voieMetTmpGen.getDict();
		
		for(Map.Entry m:dicoTmpSpe.entrySet()){
		    List<String> test = new ArrayList<String>();
		    test=(List<String>)m.getValue();
		    
		    for(int j = 0 ; j < test.size();j++) {
		    	if(test.get(j).contains(gene.getText())){
		    		cle.add((String) m.getKey());
		    	}
		    }
		}
	
		for(Map.Entry m:dicoTmpGen.entrySet()){
		    for(int k = 0 ; k < cle.size();k++) {
		    	if(((String)m.getKey()).contains((String)cle.get(k))){
				    List<String> test = new ArrayList<String>();
				    test=(List<String>)m.getValue();
		    		for(int i = 0 ; i<test.size() ; i++)
		    			listReact.add(test.get(i));
		    	}
		    }
		}
		return listReact;
	}
}
