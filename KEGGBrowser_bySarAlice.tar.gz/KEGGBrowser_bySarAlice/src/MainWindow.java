import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame ;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * Interface class that has the following methods
 * 
 * @author SarAlice Laboratory�
 * @version 2.99e8
 */
public class MainWindow extends JFrame implements ActionListener {
	
	/**
	 * The species ID of the genomic map.
	 */
	JTextField t_species1 = new JTextField();
	
	/**
	 * The species ID of the metabolic pathway.
	 */
	JTextField t_species2 = new JTextField();
	
	/**
	 * The gene ID of the genomic pathway.
	 */
	JTextField t_gene = new JTextField();
	
	/**
	 * The map ID of the metabolic pathway.
	 */
	JTextField t_map = new JTextField();
	
	/**
	 * Button Search for the genomic map.
	 */
	JButton b_search1 = new JButton("Search");
	
	/**
	 * Button Search for the metabolic pathway.
	 */
	JButton b_search2 = new JButton("Search");
	
	/**
	 * Button More for the option More.
	 */
	JButton b_more    = new JButton("More");
	
	/**
	 * Button Map Info for the map information.
	 */
	JButton b_mapInfo = new JButton("Map Info");
	
	/**
	 * Button Image for the Image.
	 */
	JButton b_image   = new JButton("Image");

	/**
	 * The Swingbox gene where the genomic map will be displayed.
	 */
	SwingBoxGene swingbox;
	
	/**
	 * The gene's information.
	 */
	GeneInfoText git_geneInfo;
	
	/**
	 * The list of reactions where the gene is involved will be displayed.
	 */
	ListReact listReact;
	
	/**
	 * The list of the gene involved in the reaction will be displayed.
	 */
	ListGene listGene; 
	
	/**
	 * The specific metabolic pathway.
	 */
	SpecificMetaboPW voiemetabo;
	
	/**
	 * The generic metabolic pathway.
	 */
	GenericMetaboPW voiemetabogen;
	
	/**
	 * The reaction's information.
	 */
	ReacInfoText rit_reacInfo;
	
	/**
	 * A temporary list
	 */
	List<String> list_genetmp;
	/**
	 * The reaction ID.
	 */
	String reaction;

	/**
	 * The dimension of the appli.
	 */
	static Dimension sizeScreen = new Dimension(1280, 820);

	public MainWindow () throws IOException{
		
		this.setTitle("KEGG Browser");
		this.setSize(sizeScreen.width+5,sizeScreen.height+45);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		
		// ******** List of objects *******
		JLabel l_gBrowser = new JLabel("Genome Browser");
		JLabel l_species1 = new JLabel("Species");
		JLabel l_species2 = new JLabel("Species"); // Oblig� d'en cr�er deux 
		JLabel l_gene = new JLabel("Gene ID");
		JLabel l_geneinfo = new JLabel("Gene Information");
		JLabel l_pBrowser = new JLabel("Pathway browser");
		JLabel l_map = new JLabel("Map ID");
		JLabel l_reacinfo = new JLabel("Reaction Information");
		JLabel l_invreac = new JLabel("Involved in reaction(s)");
		JLabel l_invgene = new JLabel("Involves gene(s)");
		
		// ******** GENE INFO ET INVOL REAC ********
		listReact 	 = new ListReact(t_species1, t_gene);
		listGene 	 = new ListGene(t_species2, t_map, list_genetmp);
		git_geneInfo = new GeneInfoText(t_species1, t_gene);
		rit_reacInfo = new ReacInfoText(reaction);
		swingbox 	 = new SwingBoxGene();
		voiemetabo 	 = new SpecificMetaboPW();
		
		JScrollPane scrollGIT = new JScrollPane(git_geneInfo);
		JScrollPane scrollListReact = new JScrollPane(listReact);
		
		// ******** CARTE GENOME ********
		JScrollPane scrollSwingBox = new JScrollPane(swingbox);
		
		// ******** VOIE METABO ********
		JScrollPane scrollMetabo = new JScrollPane(voiemetabo);
		
		// ******** REAC INFO ET INVOL GENE ********
		JScrollPane scrollRIT = new JScrollPane(rit_reacInfo);
		
		// ******** REAC INFO ET INVOL GENE ********
		JScrollPane scrollListGene = new JScrollPane(listGene); 
		
		// ******** DIMENSIONNEMENT/PLACEMENT DES OBJETS *******   - A COMPLETER
		JLabel l_emptyUpL = new JLabel("");
		JLabel l_emptyDownL = new JLabel("");
		JLabel l_emptyUpR = new JLabel("");
		JLabel l_emptyMap = new JLabel("");
		JLabel l_emptyUpC = new JLabel("");
		JLabel l_emptyDownC = new JLabel("");
		JLabel l_emptyDownR = new JLabel("");

		Dimension dimLabel = new Dimension(150,40);
		Dimension dimLabelRight = new Dimension(300,40);
		Font fontNormal = new Font("Arial", Font.PLAIN, 20);
		Font fontBold = new Font("Arial", Font.BOLD, 24);

		l_gBrowser.setFont(fontBold);
		l_gBrowser.setBackground(Color.YELLOW);
		l_gBrowser.setOpaque(true);
		l_pBrowser.setFont(fontBold);
		l_pBrowser.setBackground(Color.YELLOW);
		l_pBrowser.setOpaque(true);
		l_geneinfo.setFont(fontBold);
		l_geneinfo.setBackground(Color.YELLOW);
		l_geneinfo.setOpaque(true);
		l_reacinfo.setFont(fontBold);
		l_reacinfo.setBackground(Color.YELLOW);
		l_reacinfo.setOpaque(true);
		l_species1.setMaximumSize(dimLabel);
		l_species1.setHorizontalAlignment(SwingConstants.RIGHT);
		l_species1.setFont(fontNormal);
		
		l_species2.setMaximumSize(dimLabel);
		l_species2.setHorizontalAlignment(SwingConstants.RIGHT);
		l_species2.setFont(fontNormal);
		
		l_gene.setMaximumSize(dimLabel);
		l_gene.setHorizontalAlignment(SwingConstants.RIGHT);
		l_gene.setFont(fontNormal);
		
		l_map.setMaximumSize(dimLabel);
		l_map.setHorizontalAlignment(SwingConstants.RIGHT);
		l_map.setFont(fontNormal);
		
		l_invreac.setMaximumSize(dimLabelRight);
		l_invreac.setAlignmentX(SwingConstants.LEFT);
		l_invreac.setFont(fontNormal);
		
		l_invgene.setMaximumSize(dimLabelRight);
		l_invgene.setAlignmentX(SwingConstants.LEFT);
		l_invgene.setFont(fontNormal);

		l_emptyUpL.setMaximumSize(new Dimension(20,40));
		l_emptyUpC.setMaximumSize(new Dimension(125,40));
		l_emptyUpR.setMaximumSize(new Dimension(70,40));
		l_emptyDownL.setMaximumSize(new Dimension(10,40));
		l_emptyMap.setMaximumSize(new Dimension(25,40));
		l_emptyDownC.setMaximumSize(new Dimension(10,40));
		l_emptyDownR.setMaximumSize(new Dimension(30,40));
		
		Dimension dimTextField = new Dimension(80,40);
		Font fontTextField = new Font("Arial", Font.PLAIN, 16);
		t_species1.setMaximumSize(dimTextField);
		t_species2.setMaximumSize(dimTextField);
		t_gene.setMaximumSize(dimTextField);
		t_map.setMaximumSize(dimTextField);
		t_species1.setFont(fontTextField);
		t_species2.setFont(fontTextField);
		t_gene.setFont(fontTextField);
		t_map.setFont(fontTextField);
		
		Dimension dimButton = new Dimension(100,40);
		Font fontButton = new Font("Arial", Font.PLAIN, 16);
		b_search1.setMaximumSize(dimButton);
		b_search2.setMaximumSize(dimButton);
		b_mapInfo.setMaximumSize(dimButton);
		b_image.setMaximumSize(dimButton);
		b_more.setMaximumSize(dimButton);
		b_search1.setFont(fontButton);
		b_search2.setFont(fontButton);
		b_mapInfo.setFont(fontButton);
		b_image.setFont(fontButton);
		b_more.setFont(fontButton);

		git_geneInfo.setEditable(false);
		rit_reacInfo.setEditable(false);
		
		Dimension dimLarge = new Dimension(900,370);
		scrollSwingBox.setMinimumSize(dimLarge);
		scrollMetabo.setMinimumSize(dimLarge);
		scrollSwingBox.setPreferredSize(dimLarge);
		scrollMetabo.setPreferredSize(dimLarge);
		scrollSwingBox.setMaximumSize(dimLarge);
		scrollMetabo.setMaximumSize(dimLarge);
		
		Dimension dimInfo = new Dimension(380,200);
		Dimension dimList = new Dimension(380,130);
		scrollGIT.setMinimumSize(dimInfo);
		scrollRIT.setMinimumSize(dimInfo);
		scrollGIT.setPreferredSize(dimInfo);
		scrollRIT.setPreferredSize(dimInfo);
		scrollGIT.setMaximumSize(dimInfo);
		scrollRIT.setMaximumSize(dimInfo);
		scrollListReact.setMinimumSize(dimList);
		scrollListGene.setMinimumSize(dimList);
		scrollListReact.setPreferredSize(dimList);
		scrollListGene.setPreferredSize(dimList);
		scrollListReact.setMaximumSize(dimList);
		scrollListGene.setMaximumSize(dimList);

		// ******** LAYOUTS POSITIONING *******
		Dimension dimBoxLabel = new Dimension(sizeScreen.width,50);
		JPanel hl1 = new JPanel();
		hl1.setMaximumSize(dimBoxLabel);
		//On d�finit le layout en lui indiquant qu'il travaillera en ligne
		hl1.setLayout(new BoxLayout(hl1, BoxLayout.X_AXIS));
		hl1.add(l_gBrowser);hl1.add(l_species1); hl1.add(t_species1);
		hl1.add(l_gene); hl1.add(t_gene); hl1.add(l_emptyUpL); 
		hl1.add(b_search1); hl1.add(l_emptyUpC); hl1.add(l_geneinfo);
		 hl1.add(l_emptyUpR); hl1.add(b_more);
		
		/////
		JPanel hl2 = new JPanel();
		hl2.setLayout(new BoxLayout(hl2, BoxLayout.LINE_AXIS));
		hl2.add(scrollSwingBox);
		JPanel vl2 = new JPanel();
		vl2.setLayout(new BoxLayout(vl2, BoxLayout.PAGE_AXIS));
		vl2.add (scrollGIT) ; vl2.add(l_invreac);vl2.add (scrollListReact); 
		hl2.add(vl2);
		
		/////
		JPanel hl3 = new JPanel ();
		hl3.setMaximumSize(dimBoxLabel);
		hl3.setLayout(new BoxLayout(hl3, BoxLayout.LINE_AXIS));
		hl3.add(l_pBrowser);hl3.add(l_species2);hl3.add(t_species2);
		hl3.add(l_map); hl3.add(t_map); hl3.add(l_emptyMap); hl3.add(b_search2); 
		hl3.add(l_emptyDownL); hl3.add(b_mapInfo); hl3.add(l_emptyDownC); 
		hl3.add(l_reacinfo); hl3.add(l_emptyDownR); hl3.add(b_image);
		
		////
		JPanel hl4 = new JPanel();
		hl4.setLayout(new BoxLayout(hl4, BoxLayout.LINE_AXIS));
		hl4.add(scrollMetabo);
		JPanel vl3 = new JPanel();
		vl3.setLayout(new BoxLayout(vl3, BoxLayout.PAGE_AXIS));
		vl3.add (scrollRIT) ; vl3.add(l_invgene);vl3.add (scrollListGene); 
		hl4.add(vl3);
		
		////
		JPanel vl1 = new JPanel();
		//On positionne maintenant ces trois lignes en colonne
		vl1.setLayout(new BoxLayout(vl1, BoxLayout.PAGE_AXIS));
		vl1.setSize(1000, 1000);
		vl1.add(hl1);
		vl1.add(hl2);
		vl1.add(hl3);
		vl1.add(hl4);
		
		//On d�finit le layout � utiliser sur le content pane
		this.getContentPane().add(vl1);	
		

		// ******** INITIALIZE LISTENERS ********
		ListGeneListener lstnr_listGene = new ListGeneListener(	listGene,
																swingbox,
																t_species1,
																t_species2,
																t_gene,
																git_geneInfo,
																listReact);
		listGene.addListSelectionListener(lstnr_listGene);
		
		ListReacListener lstnr_listReac = new ListReacListener(	listReact,
																voiemetabo,
																listGene,
																rit_reacInfo,
																t_species2,
																t_map);
		listReact.addListSelectionListener(lstnr_listReac);
		
		MetaboPWMouseListener voieMetaboMouseListener
								= new MetaboPWMouseListener(	voiemetabo,
																listGene,
																rit_reacInfo,
																t_species2,
																t_species1,
																t_gene,
																t_map);
		voiemetabo.addMouseListener(voieMetaboMouseListener);
		
		b_search1.addActionListener(this);
		b_search2.addActionListener(this);
		b_mapInfo.addActionListener(this);
		b_image.addActionListener(this);
		b_more.addActionListener(this);
	}
	
	@Override 
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == b_search1) {

			GenomeWorker genomeWorker = new GenomeWorker (git_geneInfo,listReact);
			BrowserWorker browserWorker = new BrowserWorker (swingbox,t_species1, t_gene);
			browserWorker.execute();
			genomeWorker.execute();

		}
		else if (e.getSource()==b_search2) {
			
			voiemetabo.setParam( t_species2.getText(),t_map.getText());
			voiemetabogen.setParam(t_species2.getText(), t_map.getText());

		}
		else if (e.getSource()==b_image) {
			
			rit_reacInfo.showGif();
			
		}
		else if (e.getSource()==b_mapInfo) {
			
			MapInfo mapInfo = new MapInfo (t_map);
			mapInfo.getInfoMap(t_map);
			
		}
		else if (e.getSource()==b_more) {

			MoreInfo mapInfo = new MoreInfo();
		
		}
	}
}
