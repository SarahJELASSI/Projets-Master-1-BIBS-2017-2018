/* turn.h */

#ifndef GALAXY_TURN_H
#define GALAXY_TURN_H

#include "galaxy.h"
#include <stdbool.h>


void finish_move ();
bool battle_or_not (Sector);
void summary_battle();
void Aug_Power_Fleet ();
void Aug_Resources_planets ();
void end_turn ();
void end_game (char);
char has_home ();
#endif

/* turn.h */
