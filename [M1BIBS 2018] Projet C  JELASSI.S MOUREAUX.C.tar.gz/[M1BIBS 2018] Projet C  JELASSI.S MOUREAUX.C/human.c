#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"

extern Galaxy galaxy;

/*
 * The human strategy consist in showing the menu and letting the human player make whatever available actions he wants.
 * This couple of .c/.h is a little useless but it makes my main.c more clear.
 * 
 */
 
void human_strategy (){
		show_menu();
}
