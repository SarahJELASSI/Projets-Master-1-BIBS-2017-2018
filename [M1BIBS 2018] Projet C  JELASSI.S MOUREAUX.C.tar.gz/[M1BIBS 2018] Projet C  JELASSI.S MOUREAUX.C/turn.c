#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include <stdio.h>
#include <stdbool.h>

extern Galaxy galaxy;

/*
 * The end of the turn consist is 6 steps.
 * Step 1 : If there where battles that took place summarize all the battle that took place.
 * Step 2 : Taking care of the resources of the planets.
 * Step 3 : Finishing the moves.
 * Step 4 : Taking care of the firepower of the fleets.
 * Step 5 : Checking if the 2 players has an home planet or not.
 * Step 5.2 : If one of the player does not have a home planet anymore. He loses the game.
 * Step 6 : Incrementing the number of turn.
 * 
 */
void end_turn (){
	char winner;
	
	summary_battle();
	Aug_Resources_planets ();
	finish_move();
	Aug_Power_Fleet ();
	winner = has_home ();
	
	if (winner==O_AI || winner ==O_HUMAN){
		end_game (winner);
	}
	galaxy.turn ++;
	
}

/*
 * Finishing the move means 3 things : 
 * - Turning incomming fleets into stationnating fleets and explorating the sector if he was not explored. 
 * - Conquering planets, if the planet was won during a battle or if the planet was not owned.
 * - Reallocating the exploration bonus to the home planet.
 * 
 * Those 3 steps are done twice, once for the AI and once for the human player.
 * 
 */
	
void finish_move() {
	int row;
	int column;
	
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++){
	
			/* Turning incomming fleets into stationnating fleets and explorating the sector if he was not explored. For the AI */
			
			if (galaxy.sectors[row][column].inc_a>0) {
				galaxy.sectors[row][column].fleet.power += galaxy.sectors[row][column].inc_a;
				galaxy.sectors[row][column].fleet.owner=O_AI;
				galaxy.sectors[row][column].inc_a=0;
				
				if(!galaxy.sectors[row][column].explored_a){
					galaxy.sectors[row][column].explored_a=true;
				}
				
				/* Conquering planets, if the planet was won during a battle or if the planet was not owned. For the AI */
				if (galaxy.sectors[row][column].has_planet==true 
						&& galaxy.sectors[row][column].content.planet.owner!=O_AI){
					
					if (galaxy.sectors[row][column].content.planet.owner==O_HUMAN){
						printf("###################################################################\n###\n");
						printf("### Calamity! The AI conquered your planet in sector (%d,%d).\n###\n", row,column);
						printf("###################################################################\n");
						galaxy.sectors[row][column].content.planet.owner=O_AI;
					}
					else {
						galaxy.sectors[row][column].content.planet.owner=O_AI;
					}
				}
				/* Reallocating the exploration bonus to the home planet. For the AI */	
				else if (galaxy.sectors[row][column].has_planet==false 
							&& galaxy.sectors[row][column].content.res_bonus!=0){
					galaxy.sectors[galaxy.home_a.x][galaxy.home_a.y].content.planet.res_total += galaxy.sectors[row][column].content.res_bonus;
					galaxy.sectors[row][column].content.res_bonus=0;
				}
			}
			
			/* Turning incomming fleets into stationnating fleets and explorating the sector if he was not explored. For the human player */
			else if (galaxy.sectors[row][column].inc_h>0) {
				galaxy.sectors[row][column].fleet.power += galaxy.sectors[row][column].inc_h;
				galaxy.sectors[row][column].fleet.owner=O_HUMAN;
				galaxy.sectors[row][column].inc_h=0;
				
				if(!galaxy.sectors[row][column].explored_h){
					galaxy.sectors[row][column].explored_h=true;
				}
				
				/* Conquering planets, if the planet was won during a battle or if the planet was not owned. For the human player */
				if (galaxy.sectors[row][column].has_planet==true 
						&& galaxy.sectors[row][column].content.planet.owner!=O_HUMAN){
					galaxy.sectors[row][column].content.planet.owner=O_HUMAN;
					printf("###################################################################\n###\n");
					printf("### Congratulations ! The planet in sector (%d,%d) is now yours.", row,column);
					printf ("\n### It produces %d resources/turn.\n###\n", galaxy.sectors[row][column].content.planet.res_per_turn);
					printf("###################################################################\n");
					printf ("\n");
					}
				/* Reallocating the exploration bonus to the home planet. For the human player. */	
				else if (galaxy.sectors[row][column].has_planet==false 
							&& galaxy.sectors[row][column].content.res_bonus!=0){
					galaxy.sectors[galaxy.home_h.x][galaxy.home_h.y].content.planet.res_total += galaxy.sectors[row][column].content.res_bonus;
					printf("###################################################################\n$$$\n");
					printf("$$$ Exploring sector (%d,%d) grants you %d bonus resources !", row, column, galaxy.sectors[row][column].content.res_bonus);
					printf("\n$$$ Bonus resources added to sector (%d,%d)\n$$$", galaxy.home_h.x,galaxy.home_h.y);
					printf("###################################################################\n");
					galaxy.sectors[row][column].content.res_bonus=0;
					printf ("\n");
					}
			}
		}
	}
	
}
/*
 * This function determine if there will be a battle or not 
 * The input is the battlefield a.k.a a sector[row][column] in the galaxy.
 * First the same method describ in battle.c is applied:
 * A variable "firepower" is created. It's the addition of the firepower available at the sector and the firepower incomming for one player.
 * Checking if the values of firepower of the human player's and the AI's fleet are superior to 0 on the battlefield.
 * If yes the output of the function is a booleen "true", if not the output of the function is a booleen "false".
 */
bool battle_or_not (Sector battlefield){
	
	/* Creation of the variable "firepower" to determine if there is a battle. */
	int firepower_H;
	int firepower_A;
	
	firepower_A = battlefield.inc_a;
	firepower_H = battlefield.inc_h;

	if (battlefield.content.planet.owner == O_AI){
		firepower_A += battlefield.fleet.power;
	}

	if (battlefield.content.planet.owner == O_HUMAN){
		firepower_H += battlefield.fleet.power;
	}
	
	/* Checking if the values of firepower are superior to 0*/
	if (firepower_H && firepower_A){
		return true;
	}	

	return  false;
}

/*
 * Summarising the battles. 
 * The summary of the battle consist in 6 parts.
 * Part 1: Checking if there will be a battle in this sector with the function "battle_or_not". 
 * Part 2: Telling where there is a battle.
 * Part 3: Telling what kind of fleets are involded are there firepower.
 * Part 4: Doing the battle in the sector with the function battle. 
 * Part 5: Telling the firepower at the end of the battle.
 * Part 6: Telling the result of the battle.
 */
void summary_battle(){
	
	int row;
	int column;
	
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++){
			/* PART 1. */
			if (battle_or_not(galaxy.sectors[row][column])){
				/* PART 2. */
				printf ("###################################################################");
				printf("\n!!!\n!!! *** Battle in sector (%d,%d). ***\n!!!", row,column);
				if (galaxy.sectors[row][column].inc_h) {
				/* PART 3. */
					printf ("\n!!! You have an incoming fleet with firepower. %d", galaxy.sectors[row][column].inc_h);
				}
				
				if (galaxy.sectors[row][column].inc_a) {
					printf ("\n!!! The Dark AI has an incoming fleet with firepower. %d", galaxy.sectors[row][column].inc_a);
				}
				
				if (galaxy.sectors[row][column].fleet.owner==O_HUMAN) {
					printf ("\n!!! You have a fleet with firepower. %d", galaxy.sectors[row][column].fleet.power);
				}
				
				if (galaxy.sectors[row][column].fleet.owner==O_AI) {
					printf ("\n!!! The Dark AI has a fleet with firepower. %d", galaxy.sectors[row][column].fleet.power);
				}
				/* PART 4. */
				battle (row,column);
				printf("\n!!!\n!!! *** Battle summary: ***\n!!!");
				/* PART 5. */
				printf("\n!!! You have %d total firepower.",galaxy.sectors[row][column].inc_h);
				printf ("\n!!! The Dark AI has %d total firepower.",galaxy.sectors[row][column].inc_a);
				/* PART 6. */
				if (galaxy.sectors[row][column].inc_h<galaxy.sectors[row][column].inc_a ) {
					printf ("\n!!! The Dark AI won :'(");
				}
				else if (galaxy.sectors[row][column].inc_h>galaxy.sectors[row][column].inc_a) {
					printf ("\n!!! You won !!!");
				}
				else {
					printf ("\n!!! It's a tie ! :-|");
				}
				printf("\n!!!\n###################################################################\n");
			}
		}
	}
}

/*
 * Increasing the total resources of the planets in relation with their resources per turn.
 * A planet without owner does not have an increase of her total resources.
 */
void Aug_Resources_planets (){
	
	int row;
	int column;
	
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++){
			
			/* Checking if the planet in the sector [row][column] has an owner. 
			 * If yes, increasing her total resources. If not, doing nothing. 
			 */
			if ((galaxy.sectors[row][column].has_planet == true) 
					&& (galaxy.sectors[row][column].content.planet.owner != 0)) {
				galaxy.sectors[row][column].content.planet.res_total+=galaxy.sectors[row][column].content.planet.res_per_turn;
			}
		}
	}
	
}

/*
 * Increasing the firepower of the fleets.
 * When a planet has her total resources superior than the "UNIT_COST".
 * A new fleet of firepower 1 will be created at the planet location.
 * It keeps doing it while the total resources is superior than the "UNIT_COST".
 * 
 */
void Aug_Power_Fleet () {
	
	int row;
	int column;
	
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++){
			if ((galaxy.sectors[row][column].has_planet == true) 
					&& (galaxy.sectors[row][column].content.planet.owner != 0)) {
				while (galaxy.sectors[row][column].content.planet.res_total>=UNIT_COST){
					galaxy.sectors[row][column].fleet.power ++;
					galaxy.sectors[row][column].fleet.owner=galaxy.sectors[row][column].content.planet.owner;
					galaxy.sectors[row][column].content.planet.res_total-= UNIT_COST;
					if (galaxy.sectors[row][column].content.planet.owner == O_HUMAN){
						printf("###################################################################\n");
						printf(">>> \n>>> Your firepower in sector (%d,%d) has increased by 1\n>>>\n", row,column);
						printf ("###################################################################\n");
					}
				}
			}
		}
	}
}
	
/*
 * Checking if the players has a home planet and giving a new one if possible.
 * It consist if 4 Steps. This steps is done twice once for the human player and once for the AI.
 * Step 1: Checking if the AI stole the human player's home planet or the other way
 * Step 2: If yes Counting the available planets.
 * Step 3: If there is no available planet the function returns the inital of the player that stole the home planet
 * Step 4: If there is other available planets, giving a new home planet among the available ones.
 *		To simplify this step a table that contains all the available planets is created.
 */	
char has_home () {
	
	int row;
	int column;
	int compteur;
	/* Step 1: Checking if the AI stole the human player's home planet.*/
	if (galaxy.sectors[galaxy.home_h.x][galaxy.home_h.y].content.planet.owner==O_AI) {
		/* Step 2. Counting the human player's available planets*/
		compteur = 0;
		for (row=0; row<SIZE; row++) {
			for (column=0; column<SIZE; column++){
				if (galaxy.sectors[row][column].has_planet == true 
						&& galaxy.sectors[row][column].content.planet.owner==O_HUMAN)
					compteur ++;
			}
		}
		/* Step 3. Returning O_AI if the human player does not have any planets*/
		if (compteur == 0){
			return O_AI;
		}
		/* Step 4. Giving a new home planet to the human player*/
		else {
			int Tab_planet [compteur][2];
			int i=0; 
			 
			for (row=0; row<SIZE; row++) { 
				for (column=0; column<SIZE; column++){
					if (galaxy.sectors[row][column].has_planet == true 
							&& galaxy.sectors[row][column].content.planet.owner==O_HUMAN){
						Tab_planet [i][0] = row; 
						Tab_planet [i][1] = column; 
						i ++;
					}
				}
			}
			int j;
			j = random_number (0, compteur-1);
			galaxy.home_h.x = Tab_planet [j][0];
			galaxy.home_h.y = Tab_planet [j][1];	
		}
	}
	/* Step 1: Checking if the human player stole the AI's home planet.*/
	if (galaxy.sectors[galaxy.home_a.x][galaxy.home_a.y].content.planet.owner==O_HUMAN){
			/* Step 2. Counting the AI's available planets*/
			compteur = 0;
		for (row=0; row<SIZE; row++) {
			for (column=0; column<SIZE; column++){
				if (galaxy.sectors[row][column].has_planet == true 
						&& galaxy.sectors[row][column].content.planet.owner==O_AI){	
					compteur ++;
				}
			}
		}
		/* Step 3. Returning O_HUMAN if the AI does not have any planets*/
		if (compteur == 0){
			return O_HUMAN;
		}
		/* Step 4. Giving a new home planet to the AI*/
		int Tab_planet [compteur][2];
		int i=0; 
		 
		for (row=0; row<SIZE; row++) { 
			for (column=0; column<SIZE; column++){
				if (galaxy.sectors[row][column].has_planet == true 
						&& galaxy.sectors[row][column].content.planet.owner==O_AI){
					Tab_planet [i][0] = row; 
					Tab_planet [i][1] = column; 
					i ++;
					}
			}
		}		
		int j;
		j = random_number (0, compteur-1);
		galaxy.home_h.x = Tab_planet [j][0];
		galaxy.home_h.y = Tab_planet [j][1];	
	}
	
	return 0;
}

/*
 * Checking if the game is over or not. 
 * The input is the initial of the winner.
 * If the human player decides to quit the game the input is "E".
 */
void end_game (char winner){
	
	if (winner==O_AI){
		printf ("*******************************************************************");
		printf ("***\n*** GAME OVER\n***"); 
		printf ("\n*** The Dark Artificial Intelligence conquered the galaxy in %d turns ! :-(\n", galaxy.turn);
		printf ("*** Replay in order to take your revenge on the Dark Artificial Intelligence");
		printf ("\n***\n*******************************************************************\n");
		galaxy.game_over = true;
	}
	
	if (winner==O_HUMAN){
		printf ("*******************************************************************");
		printf ("***\n*** CONGRATULATIONS\n***"); 
		printf ("\n*** You conquered the galaxy in %d turns ! :-)\n", galaxy.turn);
		printf ("*** Replay in order to defeat the others Dark Artificial Intelligence");
		printf ("\n***\n*******************************************************************\n");
		galaxy.game_over = true;
	}
	
	if (winner=='E'){
		printf ("*******************************************************************");
		printf ("***\n*** Oh no !!!\n***"); 
		printf ("\n*** You deserted the galaxy :-| in %d turns \n", galaxy.turn);
		printf ("*** You let the fate of the galaxy in the Dark Artificial Intelligence's hands");
		printf ("\n***\n*******************************************************************\n");
		galaxy.game_over = true;
	}
	
}
