#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>

extern Galaxy galaxy;

/*
 * Returns a random number between min and max.
 */
unsigned short int random_number(int min,int max){
	int result;
	result = rand()% (max+1-min) +min ;
	return result;
}
	
/*
 * Initialisation of the galaxy.
 * 
 * The "Part 1" consist in creating a planet in the sector [row][column] with a probability of 0.25.
 * 		Do while there is less than 3 planets because it will be no fun...
 * The "Part 2" consist in attributing one home planet for the human player and for the AI. 
 * The home planet is randomly choosen in the group of planets created in the Part1.
 * 
 */ 
	
void init_galaxy () {
	int row;
	int column;
	int count_planets;
	
	/* 
	 * PART 1: The creation of the planets. 
	 * Picking a random number between 1 and 4.
	 */
	do {
		count_planets = 0;	
		for (row=0; row<SIZE; row++) {
			for (column=0; column<SIZE; column++){
				int planetornot = 0;
				planetornot=random_number(1,4);	
				if (planetornot	== 1) {
					galaxy.sectors[row][column].has_planet=true;
					galaxy.sectors[row][column].content.planet.res_per_turn = random_number (1,10) *100;
					count_planets ++;			
				}
				else {
					galaxy.sectors[row][column].has_planet=false;
					galaxy.sectors[row][column].content.res_bonus=random_number(1,5)*50;				
				}
			}
		}
	} while (count_planets<3);
	
	/* 
	 * PART 2: The attribution of the human player's home planet and the AI's home planet
	 * Choosing randomly the first home planet in a sector containing a planet 
	 */
	do {
		row = random_number (0,SIZE-1);
		column = random_number (0,SIZE-1);
		
		galaxy.home_a.x= row;
		galaxy.home_a.y= column;
		
	} while (galaxy.sectors[row][column].has_planet==false);
	
	/* 
	 * Choosing randomly the second home planet in a sector containing a planet.
	 * Making that it is different from the first home planet 
	 */
	int row2;
	int column2; 
	do {
		row2 = random_number (0,SIZE-1);
		column2 = random_number (0,SIZE-1);
		
		galaxy.home_h.x= row2;
		galaxy.home_h.y= column2;
		
	} while ((galaxy.sectors[row2][column2].has_planet==false) 
				|| ( (galaxy.home_a.x==galaxy.home_h.x) 
				&& (galaxy.home_a.y==galaxy.home_h.y)));
	
	/* 
	 * Firstly giving the first home planet to the AI and the second one to the human player. 
	 * Secondly creating the original fleet. Thirdly putting the resources per turn
	 */
	galaxy.sectors[row][column].content.planet.owner=O_AI;
	galaxy.sectors[row][column].fleet.owner=O_AI;
	galaxy.sectors[row][column].fleet.power=1;
	galaxy.sectors[row][column].explored_a=true;
	galaxy.sectors[row][column].content.planet.res_per_turn = 500;
	
	galaxy.sectors[row2][column2].content.planet.owner=O_HUMAN;
	galaxy.sectors[row2][column2].fleet.owner=O_HUMAN;
	galaxy.sectors[row2][column2].fleet.power=1;
	galaxy.sectors[row2][column2].explored_h=true;
	galaxy.sectors[row2][column2].content.planet.res_per_turn = 500;
		
	/*Welcoming the player in the beginning of the game*/
	printf ("\nWelcome to this galaxy ! Please save it from the terrible Dark Artificial Intelligence !!");

}




