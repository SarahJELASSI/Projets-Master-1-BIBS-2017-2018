#include <stdio.h>
#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include "human.h"
#include <stdlib.h>
#include <time.h>

extern Galaxy galaxy;

int main()
{
	srand(time (NULL));	
	init_galaxy();
	while (!galaxy.game_over){
		show_galaxy ();
		ai_strategy();
		human_strategy ();
		end_turn ();
	}
	return 0;
}

