/* battle.h */

#ifndef GALAXY_BATTLE_H
#define GALAXY_BATTLE_H

#include "galaxy.h"

void battle (int,int);

#endif

/* battle .h */
