#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include <stdio.h>
#include <stdbool.h>

extern Galaxy galaxy;

/*
 * Battle between the human player and the AI.
 * The input of the function is the location of the battle.
 * 
 * There is 3 cases that can provoque a battle : 
 *	- First one or several of human player's moving fleets encounter a stationnating AI's fleet in a sector. 
 *	- Second one or several of AI's moving fleets encounter a stationnating human player's fleet in a sector.
 *	- Third one or several of human player's moving fleets encounter ne or several of AI's moving fleets
 * 
 * So in order to simplify the battle a variable "firepower" is created. 
 * It's the addition of the firepower available at the sector and the firepower incomming for one player. 
 * 
 * There is 3 possibles outcomes to a battle: 
 *	- First the AI wins because his firepower in the sector is greater than the firepower of the human player.
 *	- Second the human player wins because his firepower in the sector is greater than the firepower of the AI
 *	- Third it's a tie because the firepower of the human player equals the firepower of the AI	
 * 
 * During the battle the firepower of the human player and of the AI obviously change.
 * So at the end of a battle the new firepower is reallocate by putting them as an incomming fleet.
 * We don't mind putting them as an incomming fleet because when all the battles will be done they will become stationnating fleet
 * We concede that it's a little ambiguous.
 * 
 */

void battle	(int row, int column){

	int firepower_H;
	int firepower_A;
	
	/* Creation of the variable "firepower" to simplify the battle. */
	firepower_A = galaxy.sectors[row][column].inc_a;
	firepower_H = galaxy.sectors[row][column].inc_h;
	
	if (galaxy.sectors[row][column].fleet.owner == O_AI){
		firepower_A += galaxy.sectors[row][column].fleet.power;
		galaxy.sectors[row][column].fleet.power=0;
	}
	else if (galaxy.sectors[row][column].fleet.owner == O_HUMAN){
		firepower_H += galaxy.sectors[row][column].fleet.power;
		galaxy.sectors[row][column].fleet.power=0;
	}

		/* VICTORY of the AI and DEFEAT of the human player. */
	if (firepower_A<firepower_H){
		firepower_A=0;
		firepower_H -=firepower_A;		
	}

		/* VICTORY of the human player and DEFEAT of the AI. */
	if (firepower_A>firepower_H){
		firepower_H=0;
		firepower_A -=firepower_H;
	}
		
		/* TIE. */
	if(firepower_A==firepower_H){
		firepower_A=0;
		firepower_H=0;
		galaxy.sectors[row][column].tie_or_loss=true;
	}
	
	/* Reallocation of the firepowers */

	galaxy.sectors[row][column].inc_a=firepower_A;
	galaxy.sectors[row][column].inc_h=firepower_H;
	
}
