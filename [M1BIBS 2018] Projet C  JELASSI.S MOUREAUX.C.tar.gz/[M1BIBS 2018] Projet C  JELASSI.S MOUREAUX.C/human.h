/* human.h */

#ifndef GALAXY_HUMAN_H
#define GALAXY_HUMAN_H

#include "galaxy.h"

void human_strategy ();

#endif

/* human.h */
