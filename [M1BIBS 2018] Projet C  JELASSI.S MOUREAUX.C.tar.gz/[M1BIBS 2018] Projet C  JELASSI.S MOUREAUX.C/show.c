#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include <stdio.h>

extern Galaxy galaxy;

/*
 * Showing the human player's fleets to him.
 * First check if the human player has any fleets or not. 
 * If the human player has fleets:
 * 	- telling him the firepower and 
 * 	- where they are "stationed" or where they will be going if the human player choose to move them.
 * If the human player does not have any fleet, telling him.
 */ 

void show_fleet () {
	int row;
	int column;
	int counts_fleets;
	
	counts_fleets=0;
	
	/*Counting the fleets in order to know what to tell to the human player.*/
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++) {
			if (galaxy.sectors[row][column].fleet.owner==O_HUMAN 
					|| galaxy.sectors[row][column].inc_h !=0 ){
				counts_fleets ++;
			}
		}
	}
	
	/*
	 * If the human player as fleets. First telling him the informations about the "stationing" fleet. 
	 * Second telling him where will be going the moving fleets
	 */
	if (counts_fleets!=0) {
		printf ("\nHere are your fleets: \n");
		for (row=0; row<SIZE; row++) {
			for (column=0; column<SIZE; column++) {
				if (galaxy.sectors[row][column].fleet.owner==O_HUMAN){
					printf ("\tSector (%d,%d) has a fleet with %d total firepower.\n", row, column, galaxy.sectors[row][column].fleet.power);
				}
			}
		}
		
		for (row=0; row<SIZE; row++) {
			for (column=0; column<SIZE; column++) {
				if (galaxy.sectors[row][column].inc_h){
					printf ("\tSector (%d,%d) has an incomming fleet with %d total firepower.\n", row, column, galaxy.sectors[row][column].inc_h);
				}
			}
		}
		printf ("\n");
	}
	
	/*If the human player does not have any fleet, telling him.*/
	else {
		printf ("\nSadly you do not have fleets... \n\n");
	}
	
}

/*
 * Showing the human player's planets to him.
 * First count how many planets has the human player.
 * Then telling him where they are, their resources per turn and their total resources.
 */ 
void show_planet () {
	 
	int row;
	int column;
	int count_planets=0;
	
	/* Counting the human player's planets and telling him how many he as.*/
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++) {
			if (galaxy.sectors[row][column].content.planet.owner==O_HUMAN){
				count_planets++;
			}
		}
	}
	printf ("\nYou have %d planets:\n", count_planets);
	
	/* 
	 * Telling informations about the human player's planets. 
	 * Like their positions, their resources per turn and their total resources.
	 */
	for (row=0; row<SIZE; row++) {
		for (column=0; column<SIZE; column++) {
			if (galaxy.sectors[row][column].content.planet.owner==O_HUMAN){
				printf ("\tPlanet in sector (%d,%d) :\n\t\tResources/turn : ", row,column);
				printf ("%d \n\t\tTotal resources : %d \n", galaxy.sectors[row][column].content.planet.res_per_turn, galaxy.sectors[row][column].content.planet.res_total);
			}
		}
	}
	printf ("\n");
}

/*
 * Showing the galaxy to the human player.
 * First telling him where his home planet is. 
 * Second show the galaxy in relation with his progress in the game.
 * Showing : " * " for the human player's planets, "@" for the AI's planets,
 * "%" where there were ties or defeats,"!?" where there will be an exploration, 
 * "?" for an non-explored sector,"o" for a stationnating fleet and " " for empty sectors.
 */ 
void show_galaxy () {
	int row;
	int column;
	char INC_NEXT_TURN ='!' ;
	char STATIO_FLEET = 'o' ;
	
	/* Telling where the human player's planet is.*/
	printf ("\nYour home planet is in sector (%d,%d).\n====================================\n", galaxy.home_h.x, galaxy.home_h.y);
	printf ("Turn #%d\n\n ", galaxy.turn);
	
	/* Showing the galaxy in relation with the human player's progress in the game.*/
	for (column=0;column<SIZE;column++){
		printf ("%4d",column);
	}
	printf ("\n  +");
	for (column=0;column<SIZE;column++){
		printf ("---+");
	}	
	printf("\n");
	for (row=0;row<SIZE;row++){
		printf ("%d |",row);
		for (column=0;column<SIZE;column++){
			if (galaxy.sectors[row][column].explored_h==true){
				if ((galaxy.sectors[row][column].has_planet == true) 
						&& (galaxy.sectors[row][column].content.planet.owner==O_HUMAN)){
					printf (" %c",O_HUMAN);
				}
				else if ((galaxy.sectors[row][column].has_planet == true) 
							&& (galaxy.sectors[row][column].content.planet.owner==O_AI)){
					printf (" %c",O_AI);
				}
				else {
					printf("  ");
				}
				if (galaxy.sectors[row][column].fleet.owner==O_HUMAN) {
					printf ("%c|", STATIO_FLEET);
				}
				else {
					printf (" |");
				}
			}
			else if (galaxy.sectors[row][column].tie_or_loss==true){
				printf (" %c |", TIE_OR_LOSS);
			}
			else if (galaxy.sectors[row][column].inc_h!=0){
				printf ("%c%c |", INC_NEXT_TURN,O_NONE);
			}
			else {
				printf(" %c |",O_NONE);
			}
		}
		printf ("\n");
		printf ("  +");		
		for (column=0;column<SIZE;column++){
			printf ("---+");
		}
		printf ("\n");
	}
}
	
/*
 * Showing the menu to the human player.
 * First telling him what are the available options in the beginning of each turn. 
 * Then after each action not repeating the after each action for lisibility issues.
 */ 
void show_menu () {
	printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
	printf("\n \tp - show your planets \n \tg - show galaxy \n ");
	printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");
	menu ();
}

/*
 * The menu function.
 * For lisibilty issues in the terminal the menu process is cut into 2 functions.
 * Showing each time what the human player can do is pointless and takes place so an option "help" is added.
 * The booleen "choice" is indicating if the player can remake an action or not. 
 * For example if "choice" is true the human player's turn is not over, if it's false the human player's turn or the game is over.
 * There is a case for each options of the game. 
 * "m" to move the fleets, "f" to show the fleets, "p" to show the planets, 
 * "g" to show the galaxy, "h" to remind the human player's available options, 
 * "t" to end the turn and "q" to quit the game.
 */
void menu () {
	char player_choice;
	bool choice=true; 
	while (choice) {
		printf ("What would you like to do ? (Press the corresponding key) \n");
		scanf ("%c", &player_choice);
		while (getchar ()!='\n'); 
		/* 
		 * Putting this in order to avoid the fact the program see the "\n" as a character that the player entered. 
		 * As beautifully said on OpenClassroom: 
		 * " Cela permet de vider le flux entrant. 
		 * En effet, la boucle lit les caractères jusqu'à ce qu'elle ait lu le \n. Celui ci n'est donc plus dans le buffer." 
		 */
		switch (player_choice) {
			case 'm': 
			allow_move();
			choice = true;
			break;
		
			case 'f': 
			show_fleet ();
			choice = true;
			break;
			
			case 'p': 
			show_planet ();
			choice = true;
			break; 
			
			case 'g': 
			show_galaxy ();
			choice = true;
			break; 
			
			case 'h':
			printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
			printf("\n \tp - show your planets \n \tg - show galaxy \n ");
			printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");
			choice = true;
			break; 
			
			case 't': 
			choice = false;
			break; 
			
			case 'q': 
			choice = false;
			end_game ('E');
			break;
			
			default: 
			printf ("Your choice is incorrect, please redo\n");
			break;
			
		}
	}
}
