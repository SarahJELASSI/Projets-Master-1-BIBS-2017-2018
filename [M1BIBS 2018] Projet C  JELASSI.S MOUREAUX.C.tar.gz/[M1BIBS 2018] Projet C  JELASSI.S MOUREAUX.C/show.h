/* show.h */

#ifndef GALAXY_SHOW_H
#define GALAXY_SHOW_H

#include "galaxy.h"

void show_galaxy ();
void show_fleet ();
void show_planet ();
void show_menu ();
void menu ();


#endif

/* show.h */
