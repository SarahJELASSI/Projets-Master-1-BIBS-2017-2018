#include "galaxy.h"
#include "ai.h"
#include "init_game.h"
#include "turn.h"
#include "show.h"
#include "movement.h"
#include "battle.h"
#include <stdio.h>


extern Galaxy galaxy;

/*
 * Moving the fleets according to the human player correct wishes.
 * The input is the sector of departure, the sector of arrival and firepower to move.
 * The moving fleet will arrive to their sector at the end of the turn.
 */ 
void move_ships (int xs, int ys, int xt, int yt, int firepower){
	
	/* If the input is correct moving the fleet from the sector of departure to the sector of arrival. 
	 * During the movement of a fleet the value of the present firepower has to change.
	 * Indeed we have to take away the firepower of the moving fleet from the firepower of the stationnating fleet.
	 * If the firepower equals 0 the fleet is "deleted" by putting his owner to 0.
	 */
	 
	if (galaxy.sectors[xs][ys].fleet.owner==O_HUMAN){
		printf ("Moving %d firepower from (%d,%d) to (%d,%d) \n", firepower,xs,ys,xt,yt);
		printf ("\n");
		galaxy.sectors[xs][ys].fleet.power= (galaxy.sectors[xs][ys].fleet.power)-firepower;
		galaxy.sectors[xt][yt].inc_h += firepower;
		if (galaxy.sectors[xs][ys].fleet.power==0){
			galaxy.sectors[xs][ys].fleet.owner=0;			
		}
	}
	
	else if (galaxy.sectors[xs][ys].fleet.owner==O_AI){
		galaxy.sectors[xs][ys].fleet.power= (galaxy.sectors[xs][ys].fleet.power)-firepower;
		galaxy.sectors[xt][yt].inc_a += firepower;
		if (galaxy.sectors[xs][ys].fleet.power==0){
			galaxy.sectors[xs][ys].fleet.owner=0;	
		}
	}
}

/*
 * Allowing the move or not according to the human player wishes. 
 * First checking if the human player has put a correct input.
 * Then telling him if he made an error and what kind of error. 
 * If the input is correct use the function move_ships. 
 */
void allow_move (){
	/* Showing and example of movement.*/
	printf ("\nFrom which sector, to which sector, and how many fleet units do you wish to move \n");
	printf ("e.g. To move a firepower of 8 from sector (1,1) to sector (2,2), type 1 1 2 2 8 \n");
	
	int xs,ys;  /*sector of departure*/
	int xt,yt;  /*sector of arrival*/
	int firepower;  /*firepower to move*/

	scanf("%d %d %d %d %d", &xs, &ys, &xt, &yt, &firepower);
	while (getchar ()!='\n');
	 /*As said ealier, putting this in order to avoid the fact the program see the "\n" as a character that the player entered. 
	 * As beautifully said on OpenClassroom: 
	 * "Cela permet de vider le flux entrant. 
	 * En effet, la boucle lit les caractères jusqu'à ce qu'elle ait lu le \n. Celui ci n'est donc plus dans le buffer." 
	 */
	
	/* Checking if the input is correct or not. */
	if (((xs>(SIZE-1)) || (ys>(SIZE-1)) || (xt>(SIZE-1)) || (yt>(SIZE-1)) )) {
		printf ("A sector coordinate cannot be greater than %d\n", (SIZE-1));
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");		
	}
	else if (((xs<0) || (ys<0) || (xt<0) || (yt<0) )) {
		printf ("A sector coordinate cannot be less than 0\n");
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");		
	}
	else if (firepower<1) {
		printf ("You must move at least 1 firepower\n");
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");		
	}						
	else if ((galaxy.sectors[xs][ys].fleet.owner!=O_HUMAN)) {
		printf ("You do not have a fleet in sector (%d,%d).\n", xs,ys);
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");		
	}
	else if ((galaxy.sectors[xs][ys].fleet.power<firepower)){
		printf ("You don't have enough firepower in the fleet at (%d,%d).\n", xs,ys);
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");		
	}
	else if ((xs==xt) && (ys==yt)){
		printf ("You can not go from one sector 'A' and move to the same sector 'A'. You will waste fuel >u<' .");
		printf ("\n");
		printf ("You have many options ! \n \tm - move fleets \n \tf - find your available fleets ");
		printf ("\n \tp - show your planets \n \tg - show galaxy \n ");
		printf ("\tt - end turn \n \th - tell me what i can do \n \tq - quit \n");	
	}	
	/* If the input is correct moving the fleet thanks to move_ships. */
	else {
		move_ships(xs,ys,xt,yt,firepower);	
	}
}
