/* init_game.h */

#ifndef GALAXY_INIT_GAME_H
#define GALAXY_INIT_GAME_H

#include "galaxy.h"


unsigned short int random_number(int , int );
void init_galaxy ();

#endif 

/* init_game.h */
