/* movement.h */

#ifndef GALAXY_MOVEMENT_H
#define GALAXY_MOVEMENT_H

#include "galaxy.h"

void allow_move ();
void move_ships (int, int, int, int, int);


#endif

/* movement.h */
